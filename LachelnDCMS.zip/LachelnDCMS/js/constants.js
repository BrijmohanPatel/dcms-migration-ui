/* var urlUpload = "http://192.168.1.15:9090/SpringRestExample/rest/emp/upload";
var urlReadData = "http://192.168.1.15:9090/SpringRestExample/rest/emp/anno";
var urlReplace = "http://192.168.1.15:9090/SpringRestExample/rest/emp/replace"; */

var urlUpload = "http://localhost:9090/SpringRestExample/rest/emp/upload";
var urlReadData = "http://localhost:9090/SpringRestExample/rest/emp/anno";
var urlReplace = "http://localhost:9090/SpringRestExample/rest/emp/replace";