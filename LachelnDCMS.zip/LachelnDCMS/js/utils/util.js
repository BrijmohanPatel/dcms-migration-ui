var jsEncode = {
    encode: function (s, k) {
        var enc = "";
        var str = "";
        // make sure that input is string
        str = s.toString();
        for (var i = 0; i < s.length; i++) {
            // create block
            var a = s.charCodeAt(i);
            // bitwise XOR
            var b = a ^ k;
            enc = enc + String.fromCharCode(b);
        }
        return enc;
    }
};
//var e = jsEncode.encode(JSON.stringify(d),"123");

function removeStartingComma(val) {
	if(val.charAt(0) == ","){
		return val.slice(1);
	}else{
		return val;
	}
}

function emailInput(val) {
    return val.replace(/[^a-zA-Z0-9\\@\\.\\_\\-]/g, '').substring(0, 150);
}

function otpInput(val) {
    return val.replace(/[^0-9]/g, '').substring(0, 6);
}

function appendLeadingZeroes(n) {
    if (n <= 9) {
        return "0" + n;
    }
    return n
}

function fromddmmyyyy_to_yyyymmdd(n) {
    var res = n.split('-');
    return res[2] + "-" + res[1] + "-" + res[0];
}

function fromyyyymmdd_to_ddmmyyyy(n) {
    //console.log("fromyyyymmdd_to_ddmmyyyy is called");
    var res = n.split('-');
    //console.log("njvnfjv"+res[2]+"-"+res[1]+"-"+res[0]);
    return res[2] + "-" + res[1] + "-" + res[0];
}

function extractDateFromISOString(isoDateString) {
    // Create a new Date object from the ISO date string
    const dateObject = new Date(isoDateString);

    // Extract the date components
    const year = dateObject.getFullYear();
    const month = String(dateObject.getMonth() + 1).padStart(2, '0');
    const day = String(dateObject.getDate()).padStart(2, '0');

    // Formatted date string in yyyy-mm-dd format
    const formattedDate = `${day}-${month}-${year}`;

    return formattedDate;
}

function snackbarFunction() {
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
}


function addressInput(val) {
  return val.replace(/[^a-zA-Z0-9 \\#\\`\\:\\.\\,\\&\\(\\)\\-]/g,'').substring(0,500);
}

function getAge(value){ //value=>  dd-mm-yyyy
        var dateStr=value.split("-")[1]+"-"+value.split("-")[0]+"-"+value.split("-")[2];
        var date=new Date(dateStr);
        var today=new Date();
        var diff=Math.floor((today-date)/31557600000);
        console.log(">>>>>"+diff);
        return diff;
}

 function smallCase(val) {
  return  val.toLowerCase().replace(/\s/g, '');
}	 

function decimalInput(val){
	return val.replace(/(\..*)\./g, '.');
}


 function isWebsite(val) {
  return val.replace(/[^a-zA-Z\\.\\_\\-\\@]/g,'').substring(0,50);
}

 function alphaNumericInput(val) {
  return val.replace(/[^[a-zA-Z0-9_]*$]/g,'').substring(0, 50);
}

function nameInput(val){
  return val.replace(/[^a-zA-Z `]/g,'').substring(0,50);
}

function mobileInput(val){
  return val.replace(/[^0-9]/g,'').substring(0,10);
}

function pincode(val){
  return val.replace(/^([1-9]{1}[0-9]{5})$/g,'').substring(0,6);
}

function numberInput(val){
	return val.replace(/[^0-9]/g,'');
}

function ageInput(val){
	return val.replace(/[^0-9]/g,'').substring(0,3);
}

function checkEmptyField(val){
	return val == undefined || val == null || val == "" || val == "NaN"
}

function validateEmail(email){
	var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
	if (reg.test(email)){
		return true; //valid email id
	}else{
		return false; // invalid email id
	}
}

function serverSideErrorMessViewer(messages){
	for (var key in messages) {
		// check if the property/key is defined in the object itself, not in parent
		if (messages.hasOwnProperty(key)) {           
			console.log(key, messages[key]);
			if(document.getElementById(key) !== null){
			   document.getElementById(key).innerHTML =  messages[key];
			}
		}
	}
}

function clearErrorMessages(messages){
	console.log("messages are "+JSON.stringify(messages));
	for (var key in messages) {
		// check if the property/key is defined in the object itself, not in parent
		if (messages.hasOwnProperty(key)) {           
			console.log("key is "+key, "mess "+messages[key]);
			if(document.getElementById(messages[key]) != null){
				document.getElementById(messages[key]).innerHTML = "";
			}
		}
	}
}

function clearErrors(checkId, setId){
	if(document.getElementById(checkId).value != "" && document.getElementById(checkId).value != undefined && document.getElementById(checkId).value != null){
		document.getElementById(setId).innerHTML = "";
	}
}

function tanNo(tanVal){
	return tanVal.substring(0,10).toUpperCase();
}

function gstNo(gstVal){
	return gstVal.substring(0,15).toUpperCase();
}

function ifscNo(gstVal){
	return gstVal.substring(0,15).toUpperCase();
}

function panNo(panVal){
	/* var reg = /^[A-Za-z]{3}[PBLJGCAFHTpbljgcafht]{1}[A-Za-z]{1}\d{4}[A-Za-z]{1}$/
	if (reg.test(panno)){
		return true; //valid email id
	}else{
		return false; // invalid email id
	} */
	
	// 
/* 	
	return panVal.replace(/^[A-Za-z]{3}[PBLJGCAFHTpbljgcafht]{1}[A-Za-z]{1}\d{4}[A-Za-z]{1}$/g,'').substring(0,10).toUpperCase();
	 */
	
	return panVal.substring(0,10).toUpperCase();
	
				/* 
			var panVal = $('#panNumber').val();
			var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
			if(regpan.test(panVal)){
			   // valid pan card number
			}else // invalid pan card number */

}

function capitalizeValue(value){
	return value.toUpperCase();
}

function aadhar(aadharno){
	/* var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/ */
//	$scope.regxPancard = /^\d{4}\s\d{4}\s\d{4}$/
	/* if (reg.test(aadharno)){
		return true; //valid email id
	}else{
		return false; // invalid email id
	} */
	return aadharno.replace(/^\d{4}\s\d{4}\s\d{4}$/g,'').substring(0,12);
}

function validateAppAadharno(checkId, setId, isMandatory) {
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if (/^[2-9]{1}[0-9]{11}$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid Aadhar number";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter Aadhar number.";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
}

function validateGstNo(checkId, setId, isMandatory) {
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if (/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{3}$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid GST number.";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter GST number.";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
}

function validatePincode(checkId, setId, isMandatory){
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if(/^([1-9]{1}[0-9]{5})$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid Pincode.";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter Pincode.";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
}

function numberOnlyInput(val){
	return val.replace(/[^\d]/g, '');
}

function allowNegativeNumber(val){
	val = val.replace(/[^-\d]/g, '');
	val = val.split("-");
	if(val[0] == ""){
		val = val.join('');
		val = "-"+val;
	}else{
		val = val.join('');
	}
	return val;
}

function validatePancardno(checkId, setId, isMandatory){
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if(/^[A-Za-z]{3}[Pp]{1}[A-Za-z]{1}\d{4}[A-Za-z]{1}$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid Pan number.";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter Pan number.";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
}

function validIFSCCode(checkId, setId, isMandatory) {
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if(/[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid IFSC number.";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter IFSC number.";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
}

function percentOnlyInput(value){
	value=value.replace(/[^\d.]/g, '');
	if(value == undefined || value == null || value == "" || value == "."){
		return "";
	}
	if(parseFloat(value)>100){		
		return Math.floor(parseInt(value)/10).toString();
	}else if (parseFloat(value) == 100){
		return parseInt(value).toString();
	}
    var valueArr = value.split(".");
    if(valueArr.length>1){
		if(valueArr[1].length>2){
			return value.substring(0,value.length-1);
		}
    	valueArr[0] += ".";
    }
    var result = valueArr.toString();
	result=result.replace(/,/g,"");
	if (valueArr.length>1 && valueArr[1].length>2){
		if(result.charAt(result.length-1) != "."){
			var result = Math.floor((parseFloat(result) * 100).toFixed(1)) / 100;
		}
	}	
	return result;
}
function decimalOnlyInput(value){
	value=value.replace(/[^\d.]/g, '').substring(0,6);
	if(value == undefined || value == null || value == "" || value == "."){
		return "0";
	}
    var valueArr = value.split(".");
    if(valueArr.length>1){
    	valueArr[0] += ".";
    }
    var result = valueArr.toString();
	result=result.replace(/,/g,"");
	if(result.charAt(result.length-1) != "."){
		console.log(">>"+result);
		console.log(">$>"+parseFloat(result));
		var result = Math.floor((parseFloat(result) * 100).toFixed(1)) / 100;
		console.log(">>>"+result);
		
	}
	return result;
}



//format date to dd-mm-yyyy
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}


function displayFormatDate(date) {
		if(date == undefined || date == null || date == ""){
			return "";
		}
		var dt = date.split('-');
		var d = new Date(dt[2]+"-"+dt[1]+"-"+dt[0]),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
	
	return [day, month, year].join('-');
}


function inrFormat(nStr) { // nStr is the input string
     nStr += '';
     x = nStr.split('.');
     x1 = x[0];
     x2 = x.length > 1 ? '.' + x[1] : '';
     var rgx = /(\d+)(\d{3})/;
     var z = 0;
     var len = String(x1).length;
     var num = parseInt((len/2)-1);
 
      while (rgx.test(x1)){
        if(z > 0){
          x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }else{
          x1 = x1.replace(rgx, '$1' + ',' + '$2');
          rgx = /(\d+)(\d{2})/;
        }
        z++;
        num--;
        if(num == 0){
          break;
        }
      }
     return x1 + x2;
}

function validateForINR(numValue){
	var reg = /^(\d+\.?\d{0,9}|\.\d{1,9})$/
	if (reg.test(numValue)){
		return true; 
	}else{
		return false;
	}
}

function validateMobileNo(checkId, setId, isMandatory) {
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if (/^([7-8-9]{1})([0-9]{9})$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid contact number.";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter Contact number.";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
 }
 
 function validateEmailId(checkId, setId, isMandatory) {
	var i = checkEmptyField(document.getElementById(checkId).value);
	if(!i){
		if (/^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/.test(document.getElementById(checkId).value)){
			document.getElementById(setId).innerHTML = "";
		}else{
			document.getElementById(setId).innerHTML = "Provide valid Email Id.";
		}
	}else{
		if(isMandatory){
			document.getElementById(setId).innerHTML = "Enter Email Id";
		}else{
			document.getElementById(setId).innerHTML = "";
		}
	}
 }

	function validateDob(checkId, setVal, setId){
		var i = checkEmptyField(document.getElementById(checkId).value);
		if(!i){
			checkDateOfBirth(checkId, setVal, setId);
		}else{
			document.getElementById(setId).innerHTML = "Please enter Date of Birth.";
		}
	}
 
	function checkDateOfBirth(checkId, setVal, setId){
		var d = new Date();
		var DOB = document.getElementById(checkId).value;
		var sp = DOB.split('-');
		console.log("Selected year is " + sp[2]);
		var selectde_date = parseInt(sp[2]);
		var current_date = d.getFullYear();
		console.log("Selected year is " + current_date);
		var final_age = (current_date - selectde_date);
		console.log("Final age is" + final_age);
		if (final_age <= 18) {
			document.getElementById(setId).innerHTML = "Applicant age must be greater than 18 years";
			return;
		}else{
			if(setVal != ""){
				document.getElementById(setVal).value = final_age;
			}
			document.getElementById(setId).innerHTML = "";
		}
	}
 
 
 function removeCommaFromINRValue(comaValue){
	console.log("Incoming value for removeCommaFromINRValue is "+comaValue);
	if(comaValue == "" || comaValue == undefined || comaValue == null || comaValue == "-Infinity" || comaValue == "Infinity"){
		return "";
	}
	
	var num = comaValue;
    var n = num.toString();
    if (n.indexOf(',') > -1) { 
		 n = n.replace( /,/g, "" );
	}
	
	console.log("removed comma value is "+n);
	return n;
} 
 
function numberFormat(val){
	if(val == "" || val == undefined || val == null){
		return "";
	}
	return val.replace(/,/g,'');
}

function dateFormat(input){
	if(input == "" || input == undefined || input == null){
		return "";
	}
    var res = input.split("-");
    return res[2]+"-"+res[1]+"-"+res[0];
}

function validateBankAccNo(num, checkId, setId){
	var count = document.getElementById(num).value;
	var accNoCheck = document.getElementById(checkId).value;
	if(accNoCheck.length == count){
		document.getElementById(setId).innerHTML = "";
	}else{
		document.getElementById(setId).innerHTML = "Length doesn't match.";
	}
}

Array.prototype.sortBy = function(p) {
	return this.slice(0).sort(function(a,b) {
		return (a[p] > b[p]) ? 1 : (a[p] < b[p]) ? -1 : 0;
	});
}

