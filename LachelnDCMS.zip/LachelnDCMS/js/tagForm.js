function createForm(result)
{
	for(var i = 0; i < result.tagdata.length; i++)
	{	
		console.log(result.tagdata[i]);
		var divTag = document.createElement("div");
		var textTag = document.createElement("div");
		var textNode = document.createTextNode(result.tagdata[i]);
		divTag.className = "col-md-2";
		divTag.id = "tag"+i;
		divTag.appendChild(textNode);
		textTag.className = "col-md-2";
		textTag.innerHTML = "<input type = 'text' class = 'form-control' name = '"+result.tagdata[i]+"' id = '"+result.tagdata[i]+"'><br/>";
		$("div#form").append(divTag);
		$("div#form").append(textTag);
		
		//document.body.appendChild(divTag);
		//document.body.appendChild(textTag);
	}
	var btnTag = document.createElement('div');
	btnTag.className = "col-md-12";
	btnTag.innerHTML = "<button class = 'btn btn-success' id = 'subjson'>submit</button>";
	$("div#form").append(btnTag);
	}
		