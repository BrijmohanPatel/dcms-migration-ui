$(document).ready(function(){
	// selectpiucker
	$('.selectpicker').selectpicker({
	});

	
});

