$(function() {
	$("#feedback-tab").click(function() {
		$("#feedback-form").toggle("slide");
	});
	
	$("#feedback-tab1").click(function() {
		$("#feedback-form").toggle("slide");
	});
});

