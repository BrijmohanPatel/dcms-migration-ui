myApp.controller('manageTreatmentController', ['manageTreatmentService', 'busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', 'appConstants', 'modalService', 'homeService', 'managePatientService',
	function (manageTreatmentService, busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, appConstants, modalService, homeService, managePatientService) {

		$scope.chooseDoctor = function () {
			console.log("chooseDoctor called");
		}


		$scope.addUnits = function () {
			console.log("Add Units is called!!");
			$('#selectTreatmntToothPopup').modal('show');
		}

		$scope.calTotalCost = function () {
			console.log("calTotalCost is called ||");
			document.getElementById("errMessage").innerHTML = "";
			try {
				var totalCountUnit = 0;

				for (i = 0; i < $scope.registerUnits.unitData.length; i++) {
					totalCountUnit = totalCountUnit + ($scope.registerUnits.unitData[i].unit_VALUE.length == 0 || $scope.registerUnits.unitData[i].unit_VALUE.length == undefined || $scope.registerUnits.unitData[i].unit_VALUE.length == null || $scope.registerUnits.unitData[i].unit_VALUE.length == "" ? 1 : $scope.registerUnits.unitData[i].unit_VALUE.length);
					console.log("value of " + i + "" + $scope.registerUnits.unitData[i].unit_VALUE.length);
				}
				console.log("totalCountUnit is" + totalCountUnit);
				if (totalCountUnit == 0) {
					totalCountUnit = 1
				}
				$scope.totalCost = $scope.unitCost * totalCountUnit;
			} catch (err) {
				document.getElementById("errMessage").innerHTML = err;
			}
		}

		$scope.deletePopUp = function (value, index) {
			console.log("clicked value index is " + index);
			$('#deleteWorkModal').modal('show');
			$scope.deleteWorkIndex = index;

		}

		function snackbarFunction() {
			var x = document.getElementById("snackbar");
			x.className = "show";
			setTimeout(function () {
				x.className = x.className.replace("show", "");
			}, 3000);
		}

		// $scope.assignTreatmentData = function () {
		// 	console.log("assign treatment is called");
		// 	var T_length = $rootScope.selectedPatientTreatmentList.length;
		// 	$scope.plans.length = 0;
		// 	var treatments = {};
		// 	$scope.ExistingTreatments["treatmentPlans"].length = 0;
		// 	for (i = 0; i < T_length; i++) {
		// 		for (j = 0; j < $rootScope.selectedPatientTreatmentList[i].plans.length; j++) {
		// 			$scope.plans.push($rootScope.selectedPatientTreatmentList[i].plans[j]);
		// 			$scope.manageTreatment["tp_id"] = $rootScope.selectedPatientTreatmentList[i].plans[j].tp_id;
		// 		}
		// 		treatments["total_amount"] = $rootScope.selectedPatientTreatmentList[i].total_amount;
		// 		treatments["status"] = $rootScope.selectedPatientTreatmentList[i].status;
		// 		treatments["tp_id"] =  $rootScope.selectedPatientTreatmentList[i].tp_id;
		// 		treatments["plans"] = $scope.plans;
		// 		treatments["treatment_start_date"] = $rootScope.selectedPatientTreatmentList[i].treatment_start_date;
		// 		treatments["treatment_end_date"] = $rootScope.selectedPatientTreatmentList[i].treatment_end_date;
		// 		$scope.ExistingTreatments["treatmentPlans"].push(treatments);
		// 		console.log("$scope.ExistingTreatments" + JSON.stringify($scope.ExistingTreatments));

		// 		if ($rootScope.selectedPatientTreatmentList[i].status == 'ACTIVE') {
		// 			$scope.currentPlanTotalAmount = $rootScope.selectedPatientTreatmentList[i].total_amount;
		// 			$scope.manageTreatment["patientId"] = $rootScope.selectedPatientTreatmentList[i].case_no;
		// 		}
		// 	}
			
		// 	$scope.getTreatments();

		// 	if($scope.ExistingTreatments["treatmentPlans"][0].status == 'CLOSED'){
		// 		console.log("inside status check if condition.");
		// 		$scope.applicantTab = 2;
		// 	}else{
		// 		$scope.applicantTab = 1;
		// 	}
		// }
	
		$scope.assignTreatmentData = function () {
			console.log("Assigned treatment plans Data is called");
			console.log("selectedPatient value is "+JSON.stringify($rootScope.selectedPatientTreatmentList));
			var treatmentPlanLength = $rootScope.selectedPatientTreatmentList.length;
			console.log("treatmentPlanLength is "+treatmentPlanLength);
			$scope.ExistingTreatments["treatmentPlans"].length = 0;
			$scope.plans.length = 0;
			$scope.ActivePlansCount = 0;
			$scope.ClosedPlansCount = 0;
			for (i = 0; i < treatmentPlanLength; i++) {
				$scope.ExistingTreatments["treatmentPlans"][i] = $rootScope.selectedPatientTreatmentList[i]; 
				
				 if($scope.ExistingTreatments["treatmentPlans"][i].status == 'CLOSED'){
					$scope.ClosedPlansCount = $scope.ClosedPlansCount+1;
				 }else if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.currentPlanTotalAmount = $rootScope.selectedPatientTreatmentList[i].total_amount;
					$scope.ActivePlansCount = $scope.ActivePlansCount +1;
					$scope.manageTreatment["tp_id"] = $scope.ExistingTreatments["treatmentPlans"][i].tp_id;
					$scope.manageTreatment["patientId"] = $scope.ExistingTreatments["treatmentPlans"][i].case_no;
				 }
			}

			angular.forEach($scope.ExistingTreatments["treatmentPlans"], function (value, key) {
				console.log("forEach"+key+JSON.stringify(value));

				if($scope.ExistingTreatments["treatmentPlans"][key].patientRegistrationDate != null){
					$scope.ExistingTreatments["treatmentPlans"][key].patientRegistrationDate = fromyyyymmdd_to_ddmmyyyy($scope.ExistingTreatments["treatmentPlans"][key].patientRegistrationDate);
				}

				if($scope.ExistingTreatments["treatmentPlans"][key].treatment_start_date != null){
					$scope.ExistingTreatments["treatmentPlans"][key].treatment_start_date = fromyyyymmdd_to_ddmmyyyy($scope.ExistingTreatments["treatmentPlans"][key].treatment_start_date);	
				}

				if($scope.ExistingTreatments["treatmentPlans"][key].treatment_end_date != null){
					$scope.ExistingTreatments["treatmentPlans"][key].treatment_end_date = fromyyyymmdd_to_ddmmyyyy($scope.ExistingTreatments["treatmentPlans"][key].treatment_end_date);
				}			
				
			});

			if($rootScope.selectedPatientTreatmentList.length > 0 ){
				$scope.addplanButtonToggle = false;
				$scope.addTreatmentPlanBox = false;
				$scope.deleteTreatmentIcon = false;
			}

			if($scope.ActivePlansCount == 0){
				$scope.addplanButtonToggle = true;
				$scope.addTreatmentPlanBox = true;
			}
			
			$scope.deleteTreatmentIcon = true;

			console.log("Existing treatment plans are::"+JSON.stringify($scope.ExistingTreatments)); 
			console.log("manageTreatment >> "+JSON.stringify($scope.manageTreatment)); 

			var TP_length = $scope.ExistingTreatments["treatmentPlans"].length;
			for (i = 0; i < TP_length; i++) {
				if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.editableIndex = i;
					break;
				}
			}
			$scope.toggleAddedTreatmentBox();
			$scope.getTreatments();
		}

		$scope.saveTreatment = function () {
			console.log("saveTreatment Called!");

			if($scope.ExistingTreatments["treatmentPlans"].length == 0){
					var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Alert',
					bodyText:"Please select the Treatment Plan and Patient."
				};
				modalService.showModal({}, modalOptions).then(function (result) { });
				return;
			}else{
				if(document.getElementById("TreatmentDate").value == undefined || document.getElementById("TreatmentDate").value == "" || document.getElementById("TreatmentDate").value == null
				|| $scope.manageTreatment.work_done == "" || $scope.payment_amount == "" || $scope.payment_amount == 0){
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText:"Please select values of Date, Work Done, and Payment"
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
					return;
				}
			}

			if ($scope.balance_amount == 0) {
				if (parseFloat($scope.payment_amount) > parseFloat($scope.currentPlanTotalAmount)) {
					alert("Payment amount cannot be greater then Total Amount");
					$scope.payment_amount = 0;
					$scope.paid_amount = parseFloat($scope.originalPaidAmount);
					$scope.balance_amount = (parseFloat($scope.currentPlanTotalAmount) - parseFloat($scope.paid_amount));
					return
				}
			} else {
				console.log("$scope.payment_amount"+$scope.payment_amount);
				console.log("$scope.balance_amount"+$scope.originalBalanceAmount);
				if (parseFloat($scope.payment_amount) > parseFloat($scope.originalBalanceAmount)) {
					alert("Payment amount cannot be greater then Balance Amount");
					$scope.payment_amount = 0;
					$scope.paid_amount = parseFloat($scope.originalPaidAmount);
					$scope.balance_amount = (parseFloat($scope.currentPlanTotalAmount) - parseFloat($scope.paid_amount));
					return
				}
			}

			var data = {};
			$scope.manageTreatment["treatment_date"] = fromddmmyyyy_to_yyyymmdd(document.getElementById("TreatmentDate").value);
			$scope.manageTreatment["balance_amount"] = $scope.balance_amount;
			$scope.manageTreatment["paid_amount"] = $scope.paid_amount;
			$scope.manageTreatment["payment_on_date"] = $scope.payment_amount;
			
			$scope.manageTreatment["patientId"] = $rootScope.selectedPatientTreatmentList[$scope.editableIndex].case_no;
			$scope.manageTreatment["tp_id"] =  $rootScope.selectedPatientTreatmentList[$scope.editableIndex].tp_id;

			if ($scope.paid_amount == $scope.currentPlanTotalAmount) {
				var planStatus = {};
				planStatus["status"] = "CLOSED";
				data["treatmentPlanData"] = planStatus;
			}else{
				var planStatus = {};
				planStatus["status"] = "ACTIVE";
				data["treatmentPlanData"] = planStatus;
			}
			console.log("$scope.manageTreatment value is " + JSON.stringify($scope.manageTreatment));
			data["treatmentData"] = $scope.manageTreatment;

			console.log("$scope.balance_amount" + $scope.balance_amount);
			console.log("$scope.payment_amount"+ $scope.payment_amount);
			console.log("$scope.paid_amount"+ $scope.paid_amount);


			manageTreatmentService.addTreatmentService(data, function (response) {
				console.log("Response from addTreatmentService is " + JSON.stringify(response));
				if (response.status == 'success') {
					//$scope.getTreatments();
					if($rootScope.selectedPatientTreatmentList[0].tp_id ==  response.data.treatmentPlanData.tp_id){
						$rootScope.selectedPatientTreatmentList[0].status = response.data.treatmentPlanData.status;
						if(response.data.treatmentPlanData.status == 'CLOSED'){
							$scope.applicantTab = 2;
						}
					}
					
					$scope.toggleAddedTreatmentBox(response.data.treatmentPlanList);

					$scope.assignTreatmentData();
					$scope.clearTreatmentData();
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		}

		$scope.toggleAddedTreatmentBox = function(treatmentPlanListParam){
			console.log("treatmentPlanList is "+JSON.stringify(treatmentPlanListParam));
			$scope.treatmentPlanList = [];
			$scope.treatmentPlanList = treatmentPlanListParam == undefined ? [] : treatmentPlanListParam ;
			if($scope.treatmentPlanList.length <= 0){
				$scope.treatmentPlanList = $rootScope.selectedPatientTreatmentList;
			}

			var activeTrtPlcount = 0;
			var trtLength = $scope.treatmentPlanList.length;
			for(i = 0;i<trtLength;i++){
				if($scope.treatmentPlanList[i].status == 'ACTIVE'){
					activeTrtPlcount++;
				}
			}
			if(activeTrtPlcount > 0){
				$scope.addedTreatment = true;
			}else{
				$scope.addedTreatment = false;
			}
		}

		$scope.clearTreatmentData = function (){
			console.log("$scope.clearTreatmentData is called");
			$scope.manageTreatment = {};
			$scope.manageTreatment["toothData"] = {};
			$scope.addWorkDoneBox = false;
			$scope.toothSelector('CLEAR');
			//$scope.addWorkDoneButton = false;
			//$scope.editWorkDoneButton = true;
		};

		$scope.toggleAddWorkDoneBox = function(){
			if($scope.addWorkDoneBox == true)
			{
				$scope.addWorkDoneBox = false;
			}else{
				$scope.addWorkDoneBox = true;
			}

			$scope.manageTreatment = {};
			$scope.manageTreatment["toothData"] = {};
			$scope.toothSelector('CLEAR');
		}

		$scope.getTreatments = function () {
			console.log("$scope.manageTreatment value is " + JSON.stringify($scope.manageTreatment));
			var data = {};
			data["treatmentData"] = $scope.manageTreatment;
			manageTreatmentService.getTreatmentService(data, function (response) {
				console.log("Response from getTreatmentService is " + JSON.stringify(response));
				if (response.status == 'success') {
					$scope.treatmentList = response.data.treatmentsList;
					var trt_length = $scope.treatmentList.length;
					console.log("treatmentLsit length is"+$scope.treatmentList.length);
					//$scope.showOnlyOnLastTreament = $scope.treatmentList.length; // this is to display delete button only on the last treatment.
					if($scope.treatmentList.length > 0){
						$scope.originalPaidAmount = $scope.treatmentList[trt_length-1].paid_amount;
						$scope.originalBalanceAmount = $scope.treatmentList[trt_length-1].balance_amount;
						$scope.balance_amount = $scope.originalBalanceAmount;
						$scope.paid_amount = $scope.originalPaidAmount;
						$scope.payment_amount = 0;
					}else{
						$scope.originalPaidAmount = 0;
						// Brijmohan - 29-12-2021 12:09 PM
						// In $scope.treatmentList[0].total_amount,  this will always get zero index data because in GetTreatment() method, we are only searching either Active or Closed plan at a time.
						if(response.data.treatmentPlanList.length > 0){
							$scope.originalBalanceAmount = response.data.treatmentPlanList[0].total_balance_amount;
						}						
						$scope.balance_amount = $scope.originalBalanceAmount;
						$scope.paid_amount = $scope.originalPaidAmount;
						$scope.payment_amount = 0;
					}

					//$scope.treatmentList.length
					angular.forEach($scope.treatmentList, function (val, key) {
						if($scope.treatmentList[key].treatment_date != null){
							$scope.treatmentList[key].treatment_date = fromyyyymmdd_to_ddmmyyyy($scope.treatmentList[key].treatment_date);
						}						
					});


					console.log("************************************");
					console.log("$rootScope.selectedPatientTreatmentList"+JSON.stringify($rootScope.selectedPatientTreatmentList));
					console.log("$scope.manageTreatment"+JSON.stringify($scope.manageTreatment));
					console.log("$scope.ExistingTreatments"+JSON.stringify($scope.ExistingTreatments));
					console.log("$scope.treatmentList"+JSON.stringify($scope.treatmentList));
					console.log("************************************");
					if($scope.treatmentList.length <= 0){
						$scope.addWorkDoneBox = false;
					}else{
						$scope.addWorkDoneBox = false;
					}


				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		}

		$scope.calOtherAmounts = function () {
			console.log("calOtherAmounts is called ||");
			document.getElementById("errMessage").innerHTML = "";
			if($scope.updateIndex >= 0){
					var TP = 0;
					var TB = 0;
				if($scope.updateIndex == 0){
						TP = parseFloat(TP) + parseFloat($scope.payment_amount);
						TB = parseFloat($scope.currentPlanTotalAmount) - parseFloat(TP);
						
				}else{
						TP = parseFloat($scope.treatmentList[$scope.updateIndex-1].paid_amount) + parseFloat($scope.payment_amount);
						TB = parseFloat($scope.currentPlanTotalAmount) - parseFloat(TP);
				}

				$scope.paid_amount = TP;
				$scope.balance_amount = TB;

			}else if($scope.updateIndex < 0){
				try {
					console.log("Before PAID AMT = " + parseFloat($scope.paid_amount));
					console.log("Before PYMT AMT = " + parseFloat($scope.payment_amount));
					console.log("Before ORGPAID AMT = " + parseFloat($scope.originalPaidAmount));
					console.log("Before TOTAL AMT = " + parseFloat($scope.currentPlanTotalAmount));
					console.log("Before BALANCE AMT" + $scope.balance_amount);
	
					if (parseFloat($scope.currentPlanTotalAmount) == parseFloat($scope.originalPaidAmount)) {
						alert("All Payments are Clear !!");
						$scope.payment_amount = 0;
						return
					}
	
					if (parseFloat($scope.paid_amount) == 0) {
						$scope.paid_amount = parseFloat($scope.payment_amount);
					} else {
						if (!checkEmptyField($scope.payment_amount)) {
							$scope.paid_amount = parseFloat($scope.originalPaidAmount);
							$scope.paid_amount = parseFloat($scope.originalPaidAmount) + parseFloat($scope.payment_amount);
						} else {
							$scope.paid_amount = parseFloat($scope.originalPaidAmount);
						}
					}
	
					$scope.balance_amount = (parseFloat($scope.currentPlanTotalAmount) - parseFloat($scope.paid_amount));
	
					console.log("After PAID AMT" + $scope.paid_amount);
					console.log("After PYMT AMT" + $scope.payment_amount);
					console.log("After ORGPAID AMT" + $scope.originalPaidAmount);
					console.log("After BALANCE AMT" + $scope.balance_amount);
	
				} catch (err) {
					document.getElementById("errMessage").innerHTML = err;
				}
			}
			
		}

		$scope.addTooth = function () {
			console.log("$scope.toothnumber ::" + JSON.stringify($scope.treatmentToothNumber));
			$scope.upperLeft.length = 0;
			$scope.upperLeft.length = 0;
			$scope.upperRight.length = 0;
			$scope.lowerLeft.length = 0;
			$scope.lowerRight.length = 0;

			angular.forEach($scope.treatmentToothNumber, function (val, key) {
				console.log(key);

				if (val == true) {
					if (key.charAt(0) == 'U') {
						if (key.charAt(1) == 'L') {
							$scope.upperLeft.push(key.charAt(2));
						} else if (key.charAt(1) == 'R') {
							$scope.upperRight.push(key.charAt(2));
						}
					} else if (key.charAt(0) == 'L') {
						if (key.charAt(1) == 'L') {
							$scope.lowerLeft.push(key.charAt(2));
						} else if (key.charAt(1) == 'R') {
							$scope.lowerRight.push(key.charAt(2));
						}
					}
				} else if (val == false) {
					delete $scope.treatmentToothNumber[key];
				}

			});

			$scope.manageTreatment["toothData"]["upperLeftTooth"] = removeStartingComma($scope.upperLeft.toString());
			$scope.manageTreatment["toothData"]["upperRightTooth"] = removeStartingComma($scope.upperRight.toString());
			$scope.manageTreatment["toothData"]["lowerLeftTooth"] = removeStartingComma($scope.lowerLeft.toString());
			$scope.manageTreatment["toothData"]["lowerRightTooth"] = removeStartingComma($scope.lowerRight.toString());

			console.log(JSON.stringify($scope.manageTreatment));
		}

		$scope.toothSelector = function (value) {
			if (value === "OK") {
				$('#selectTreatmntToothPopup').modal('hide');
			} else if (value === "CLEAR") {
				$('#selectTreatmntToothPopup').modal('hide');
				$scope.manageTreatment["toothData"] = {};
				$scope.treatmentToothNumber = {};
			}
		}

		$scope.deleteTreatmentPopUp = function(value){
			console.log("value received from delete is ::"+JSON.stringify(value));
			$scope.deleteTreatmentId = value;
			$('#deleteTreatmentModal').modal('show');
		}

		$scope.deleteTreatment = function(value){
			console.log("deleteTreatment called ");
			if (value == 'delete') {
				$('#deleteTreatmentModal').modal('hide');
				var data = {};
				var treatmentData = {};
				treatmentData["t_id"] = $scope.deleteTreatmentId;
				treatmentData["tp_id"] = $rootScope.selectedPatientTreatmentList[$scope.editableIndex].tp_id;
				data["treatmentData"] = treatmentData;
				manageTreatmentService.deleteTreatmentService(data, function (response) {
					console.log("Response from deleteTreatmentService is " + JSON.stringify(response));
					if (response.status == 'success') {
						$scope.assignTreatmentData();
						$scope.deleteTreatmentId = "";
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Information',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					} else if (response.status === "failed") {
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					}
				});
			}else if(value == 'cancel'){
				$('#deleteTreatmentModal').modal('hide');
			}
		}


		$scope.editTreatment = function(treatmentdata, index){
			console.log("EditTreatment is called.");
			console.log("editing treatment data"+JSON.stringify(treatmentdata[index]));
			$scope.updateIndex = index;
			$scope.ShowSaveTrtBtnDiv = false;
			$scope.ShowUpdateTrtBtnDiv = true;
			$scope.addWorkDoneBox = true;
			$scope.manageTreatment = {};
			$scope.manageTreatment = treatmentdata[index];
			$scope.manageTreatment["toothData"] = {};
			$scope.manageTreatment["toothData"]["upperLeftTooth"] = treatmentdata[index].upperLeftTooth;
			var str_array = treatmentdata[index].upperLeftTooth.split(',');
			for(var i = 0; i < str_array.length; i++) {
				$scope.treatmentToothNumber["UL"+str_array] = true;
			}
			
			$scope.manageTreatment["toothData"]["upperRightTooth"] = treatmentdata[index].upperRightTooth;
			str_array = treatmentdata[index].upperRightTooth.split(',');
			for(var i = 0; i < str_array.length; i++) {
				$scope.treatmentToothNumber["UR"+str_array] = true;
			}
			$scope.manageTreatment["toothData"]["lowerLeftTooth"] = treatmentdata[index].lowerLeftTooth;
			str_array = treatmentdata[index].lowerLeftTooth.split(',');
			for(var i = 0; i < str_array.length; i++) {
				$scope.treatmentToothNumber["LL"+str_array] = true;
			}
			$scope.manageTreatment["toothData"]["lowerRightTooth"] = treatmentdata[index].lowerRightTooth;
			str_array = treatmentdata[index].lowerRightTooth.split(',');
			for(var i = 0; i < str_array.length; i++) {
				$scope.treatmentToothNumber["LR"+str_array] = true;
			}


			//$scope.currentPlanTotalAmount = treatmentdata[index].upperLeftTooth;
			$scope.balance_amount = treatmentdata[index].balance_amount;
			$scope.paid_amount = treatmentdata[index].paid_amount;
			$scope.originalPaidAmount = $scope.paid_amount;
			$scope.payment_amount = treatmentdata[index].payment_on_date;
		}

		$scope.updateTreatments = function (){
			console.log("update Treatment Called.");

			if($scope.payment_amount == 0){
				alert("Payment cannot be zero.");
				return
			}

			$scope.manageTreatment["treatment_date"] = fromddmmyyyy_to_yyyymmdd(document.getElementById("TreatmentDate").value);
			$scope.manageTreatment["balance_amount"] = $scope.balance_amount;
			$scope.manageTreatment["paid_amount"] = $scope.paid_amount;
			$scope.manageTreatment["payment_on_date"] = $scope.payment_amount;
			
			delete $scope.manageTreatment.lowerLeftTooth;
			delete $scope.manageTreatment.lowerRightTooth;
			delete $scope.manageTreatment.upperRightTooth;
			delete $scope.manageTreatment.upperLeftTooth;
			delete $scope.manageTreatment.$$hashKey;
			delete $scope.manageTreatment.treatment_added_date;
			console.log("update treatment data is :"+JSON.stringify($scope.manageTreatment));

			var data = {};
			data["treatmentData"] = $scope.manageTreatment
			console.log("treatmentData value is ::"+JSON.stringify(data));

			manageTreatmentService.updateTreatmentService(data, function (response) {
				console.log("Response from updateTreatmentService is " + JSON.stringify(response));
				if (response.status == 'success') {
					$scope.assignTreatmentData();
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});

		}

		$scope.cancelUpdate = function (){
			console.log("cancel update called.");
			$scope.balance_amount = $rootScope.selectedPatientTreatmentList[$scope.editableIndex].total_balance_amount;
			$scope.paid_amount = $rootScope.selectedPatientTreatmentList[$scope.editableIndex].total_paid_amount;
			$scope.originalPaidAmount = $scope.paid_amount;
			document.getElementById("TreatmentDate").value = "";
			$scope.payment_amount = 0;
			$scope.toothSelector('CLEAR');
			$scope.ShowSaveTrtBtnDiv = true;
			$scope.ShowUpdateTrtBtnDiv = false;
			$scope.manageTreatment = {};
			$scope.manageTreatment["toothData"] = {};
			$scope.updateIndex = -1;
		}

		$scope.fetchworkDoneMaster = function (){
			console.log("fetchworkDoneMaster called");
			manageTreatmentService.fetchworkDoneMasterService(function (response) {
			console.log("Response from the server is "+JSON.stringify(response));
				if (response.status == 'success') {
					if(response.data.workdoneMasterList.length == 0){
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: "No Work is present!"
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
						$scope.workdoneMasterList = [];
					}else{
						$scope.workdoneMasterList = response.data.workdoneMasterList;
						$scope.workMasterList = [];
						angular.forEach($scope.workdoneMasterList, function (value, key) {
							$scope.workMasterList.push(value.work_name);
						});

						console.log("$scope.workMasterList is "+ JSON.stringify($scope.workMasterList));
					}
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }

			});
		};

		$scope.closedTreatmentPopUp = function (value){
			console.log("closedTreatmentPopUp called.");
			$('#closedTreatmentDetails').modal('show');
			$scope.closedTreatmentPlanID_IS = value;
			$scope.manageTreatment["tp_id"] = value;
			$scope.getTreatments();
		}

		$scope.showTab = function (tab) {
			console.log("Show tab:" + tab);
			for (var i = 1; i <= 2; i++) {
			   $("#tab_" + i).hide();
			}
			$("#" + tab).show();

			if(tab=='tab_1'){
				$scope.toggleAddedTreatmentBox();
				$scope.applicantTab=1;
			}else if(tab=='tab_2'){
				$scope.applicantTab=2;
				$scope.addedTreatment  = false;
			}
			
		 }

		function initialize() {
			console.log("manageTreatmentController loaded");
			busyNotificationService.hideBusyIndicator();
			if (window.performance) { // this will change once login is started.
				console.info("window.performance works fine on this browser");
			}
			if (performance.navigation.type == 1) {
				console.info("This page is reloaded");
				$state.go('login');
			} else {
				console.info("This page is not reloaded");
			}
			$scope.manageTreatment = {};
			$scope.manageTreatment["toothData"] = {};
			$scope.applicantTab = 1;
			$scope.activeTab = 1;
			$scope.oldActiveTab = 1;
			$scope.treatmentToothNumber = {};
			$scope.upperLeft = [];
			$scope.upperRight = [];
			$scope.lowerLeft = [];
			$scope.lowerRight = [];
			$scope.treatmentList = [];

			$scope.balance_amount = 0;
			$scope.paid_amount = 0;
			$scope.currentPlanTotalAmount = 0;
			$scope.payment_amount = 0;
			$scope.originalPaidAmount = 0;
			$scope.originalBalanceAmount = 0;

			$scope.ExistingTreatments = {};
			$scope.ExistingTreatments["treatmentPlans"] = [];
			$scope.plans = [];
			$scope.ShowSaveTrtBtnDiv = true;
			$scope.ShowUpdateTrtBtnDiv = false;
			$scope.updateIndex = -1;
			$scope.addWorkDoneBox = false;
			$scope.closedTreatmentDetails = false;
			$scope.ActivePlansCount = 0;
			$scope.ClosedPlansCount = 0;
			$scope.addedTreatment = true;
			

			if (!checkEmptyField($rootScope.selectedPatientTreatmentList)) {
				if ($rootScope.selectedPatientTreatmentList.length > 0) {
					$scope.assignTreatmentData();
				}
			}else{
				$rootScope.selectedPatientTreatmentList = [];
			}

			if(checkEmptyField($scope.workdoneMasterList)){
				$scope.fetchworkDoneMaster();
			}
		}


		initialize();
	}
]);