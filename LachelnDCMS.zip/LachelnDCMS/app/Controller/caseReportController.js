myApp.controller('caseReportController', ['busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', '$stateParams', 'appConstants', 'modalService', 'homeService', 'managePatientService', 'caseReportService',
    function (busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, $stateParams, appConstants, modalService, homeService, managePatientService, caseReportService) {

        $scope.assignTreatmentData = function () {
			console.log("Assigned treatment plans Data is called");
			console.log("selectedPatient value is "+$rootScope.selectedPatientTreatmentList);
			var treatmentPlanLength = $rootScope.selectedPatientTreatmentList.length;
			console.log("treatmentPlanLength is "+treatmentPlanLength);
			$scope.ExistingTreatments["treatmentPlans"].length = 0;
			$scope.ActivePlansCount = 0;
			$scope.ClosedPlansCount = 0;
			for (i = 0; i < treatmentPlanLength; i++) {
				$scope.ExistingTreatments["treatmentPlans"][i] = $rootScope.selectedPatientTreatmentList[i]; 
				 if($scope.ExistingTreatments["treatmentPlans"][i].status == 'CLOSED'){
					$scope.ClosedPlansCount = $scope.ClosedPlansCount+1;
				 }else if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.ActivePlansCount = $scope.ActivePlansCount +1;
					$scope.manageTreatment["tp_id"] = $scope.ExistingTreatments["treatmentPlans"][i].tp_id;
					$scope.manageTreatment["patientId"] = $scope.ExistingTreatments["treatmentPlans"][i].case_no;
				 }

                 
                //  var planLength = $scope.ExistingTreatments["treatmentPlans"][i].plans.length;
                //  console.log("plan length"+planLength);
                //  for(j=0;j<planLength;j++){
                //     console.log("inside plan if condition");
                //     console.log("value of j is "+j);
                //     console.log($scope.ExistingTreatments["treatmentPlans"][i].plans[j]);
                //     $scope.ExistingTreatments["plans"].push($scope.ExistingTreatments["treatmentPlans"][i].plans[j]);
                //  }
			}

			console.log("Existing treatment plans are::"+JSON.stringify($scope.ExistingTreatments)); 
			console.log("manageTreatment >> "+JSON.stringify($scope.manageTreatment));
		}


        $scope.getReport = function () {
            console.log("Get Report called.");
            console.log("selected caseTreatmentPlanID is "+JSON.stringify($scope.caseTreatmentPlanID));
            console.log("selectedPatient value is "+JSON.stringify($rootScope.selectedPatient));

            if($scope.caseTreatmentPlanID != null){
                $scope.toggleCaseReport = true;
                $('#caseReportErrorModal').modal('hide');
            }else{
                $('#caseReportErrorModal').modal('show');
                $scope.toggleCaseReport = false;
                return;
            }

            var treatmentData = {};
            treatmentData["patientId"] = $rootScope.selectedPatient.patientId;
            treatmentData["tp_id"] = $scope.caseTreatmentPlanID.tp_id;
            var data = {};
            data["treatmentData"] = treatmentData;
            console.log("Request to server is"+JSON.stringify(data));

            caseReportService.getReportService(data, function (response) {
                console.log(JSON.stringify(response));
				if (response.status == 'success') {
					var serverResponse = response;
					if (serverResponse.status == "success") {
                        $scope.patientListCaseReport = response.data.patientsList;
                        $scope.treatmentPlanListCaseReport = response.data.treatmentPlanList;
                        $scope.treatmentsListCaseReport = response.data.treatmentsList;
                        
                        angular.forEach($scope.patientListCaseReport, function (value, key) {
							console.log("forEach"+key+JSON.stringify(value));
							$scope.patientListCaseReport[key].patientRegistrationDate = fromyyyymmdd_to_ddmmyyyy($scope.patientListCaseReport[key].patientRegistrationDate);
						});

                        angular.forEach($scope.treatmentsListCaseReport, function (value, key) {
							console.log("forEach"+key+JSON.stringify(value));
							$scope.treatmentsListCaseReport[key].treatment_date = fromyyyymmdd_to_ddmmyyyy($scope.treatmentsListCaseReport[key].treatment_date);
						});
					}
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
                    modalService.showModal({}, modalOptions).then(function (result) { });
				}
            });
        }

        $scope.downloadReport = function () {
            var treatmentData = {};
            treatmentData["patientId"] = $rootScope.selectedPatient.patientId;
            treatmentData["tp_id"] = $scope.caseTreatmentPlanID.tp_id;
            var data = {};
            data["treatmentData"] = treatmentData;
            console.log("Request to server is"+JSON.stringify(data));
            caseReportService.downloadReportService(data, function (response) {
                if (response.status.toLowerCase() == 'success') {
                    var uint8Array = new Uint8Array(response.fileData);
                    var arrayBuffer = uint8Array.buffer;
                    var blob = new Blob([arrayBuffer], {
                        type: 'application/pdf'
                    });
                    
                    /*Below Code to open file.*/
                        //var fileURL = URL.createObjectURL(blob);
                        //window.open(fileURL, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=10,left=10,width=500,height=500");
                    /*Code End*/
                    
                    /*Below Code to Download file*/
                        var reportName = response.data.treatmentPlanList[0].case_no+"_"+response.data.treatmentPlanList[0].tp_id+"_"+Date.now();
                        var link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);
                        var fileName = reportName;
                        link.download = fileName;
                        link.click();
                    /*Code End.*/


                } else {
                    console.log("Error:" + JSON.stringify(response));
                }
            });
        }


        $scope.cancelReportBox = function () {
            $('#caseReportErrorModal').modal('hide');
        }

        function initialize() {
            console.log("caseReportController loaded");
            busyNotificationService.hideBusyIndicator();
            //busyNotificationService.showBusyIndicator();
            if (window.performance) { // this will change once login is started.
                //console.info("window.performance works fine on this browser");
            }
            if (performance.navigation.type == 1) {
                //console.info("This page is reloaded");
                $state.go('login');
            } else {
                //console.info("This page is not reloaded");
            }

            $scope.ExistingTreatments = {};
			$scope.ExistingTreatments["treatmentPlans"] = [];
            $scope.ExistingTreatments["plans"] = [];

            $scope.patientListCaseReport = [];
            $scope.treatmentPlanListCaseReport = [];
            $scope.treatmentsListCaseReport = [];
            $scope.toggleCaseReport = false;
            $scope.manageTreatment = {};
			$scope.manageTreatment["toothData"] = {};
            

            if (!checkEmptyField($rootScope.selectedPatientTreatmentList)) {
				if ($rootScope.selectedPatientTreatmentList.length > 0) {
					$scope.assignTreatmentData();
				}
			}

        }


        initialize();
    }
]);