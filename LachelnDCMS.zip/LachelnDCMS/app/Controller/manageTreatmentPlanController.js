myApp.controller('manageTreatmentPlanController', ['busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', 'appConstants', 'modalService', 'homeService', 'headerService','manageTreatmentPlanService','manageTreatmentService',
	function (busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, appConstants, modalService, homeService, headerService, manageTreatmentPlanService, manageTreatmentService) {

		function showModalPopUp(message) {
			var modalOptions = {
				isCloseEnabled: false,
				headerText: 'Information',
				bodyText: message
			};
			modalService.showModal({}, modalOptions).then(function (result) { });
		}

		$scope.addMoreTreatmentPlan = function () {
			console.log("Add addMoreTreatmentPlan is called!!");

			console.log($scope.treatmentPlans["plans"].length);

			if ($scope.treatmentPlans["plans"].length == 6) {
				var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Information',
					bodyText: 'You not allowed to enter more than 6 values.'
				};
				modalService.showModal({}, modalOptions).then(function (result) { });
				return false;
			} else {

				for (i = 0; i < $scope.treatmentPlans["plans"].length; i++) {
					$scope.planReadonly[i] = true;
				}

				$scope.treatmentPlans["plans"].push({
					"treatment": "",
					"estimatedAmount": "",
					"upperLeftTooth": "",
					"upperRightTooth": "",
					"lowerLeftTooth": "",
					"lowerRightTooth": ""
				});

				flushToothSelector();

				if ($scope.treatmentPlans["plans"].length == 1) {
					$scope.treatmentPlanIndex = 0;
				} else if ($scope.treatmentPlans["plans"].length > 1) {
					$scope.treatmentPlanIndex = (($scope.treatmentPlans["plans"].length) - 1)
				}

				$scope.planReadonly[$scope.treatmentPlanIndex] = false
				$scope.highlightIndex = $scope.treatmentPlanIndex;
			}
		}

		$scope.chooseDoctor = function () {
			console.log("chooseDoctor called");
		}

		$scope.checkDateErr = function (startDate, endDate) {
			console.log("StartDate values are: " + startDate); // prints true (correct)
			console.log("endDate values are: " + endDate); // prints true (correct)

			$scope.errMessage = '';
			var startD = new Date(startDate);
			var endD = new Date(endDate);

			if (startDate > endDate) {
				var modalOptions = {
					isCloseEnabled: false,
					headerText: '',
					bodyText: "End Date should be greate than start date"
				};
				modalService.showModal({}, modalOptions).then(function (result) { });

				return false;
			} else {
				return true;
			}
		};

		$scope.addTooth = function () {

			if ($scope.treatmentPlans["plans"].length == 0) {
				$scope.toothnumber = {}; //FLUSHING
				var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Information',
					bodyText: 'Please add plan!'
				};
				modalService.showModal({}, modalOptions).then(function (result) { });
				return false;
			}

			console.log("$scope.toothnumber ::" + JSON.stringify($scope.toothnumber));
			$scope.upperLeft.length = 0;
			$scope.upperLeft.length = 0;
			$scope.upperRight.length = 0;
			$scope.lowerLeft.length = 0;
			$scope.lowerRight.length = 0;

			angular.forEach($scope.toothnumber, function (val, key) {
				console.log(key);

				if (val == true) {
					if (key.charAt(0) == 'U') {
						if (key.charAt(1) == 'L') {
							$scope.upperLeft.push(key.charAt(2));
						} else if (key.charAt(1) == 'R') {
							$scope.upperRight.push(key.charAt(2));
						}
					} else if (key.charAt(0) == 'L') {
						if (key.charAt(1) == 'L') {
							$scope.lowerLeft.push(key.charAt(2));
						} else if (key.charAt(1) == 'R') {
							$scope.lowerRight.push(key.charAt(2));
						}
					}
				} else if (val == false) {
					delete $scope.toothnumber[key];
				}

			});

			console.log("$scope.treatmentPlan length is :: " + $scope.treatmentPlans["plans"].length);
			console.log("treatmentPlan indesx :: " + $scope.treatmentPlanIndex);

			if ($scope.treatmentPlans["plans"][$scope.treatmentPlanIndex] == undefined || $scope.treatmentPlans["plans"][$scope.treatmentPlanIndex] == "" || $scope.treatmentPlans["plans"][$scope.treatmentPlanIndex] == null) {

				var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Information',
					bodyText: 'Please select the plan to edit'
				};
				modalService.showModal({}, modalOptions).then(function (result) { });
				return false;

			} else {
				$scope.treatmentPlans["plans"][$scope.treatmentPlanIndex].upperLeftTooth = removeStartingComma($scope.upperLeft.toString());
				$scope.treatmentPlans["plans"][$scope.treatmentPlanIndex].upperRightTooth = removeStartingComma($scope.upperRight.toString());
				$scope.treatmentPlans["plans"][$scope.treatmentPlanIndex].lowerLeftTooth = removeStartingComma($scope.lowerLeft.toString());
				$scope.treatmentPlans["plans"][$scope.treatmentPlanIndex].lowerRightTooth = removeStartingComma($scope.lowerRight.toString());
			}

		}

		$scope.getTotal = function () {
			console.log("getTotal is called ||");
			document.getElementById("errMessage").innerHTML = "";
			try {
				var totalCountUnit = 0;
				for (i = 0; i < $scope.treatmentPlans["plans"].length; i++) {
					if (!checkEmptyField($scope.treatmentPlans["plans"][i].estimatedAmount)) {
						totalCountUnit = parseFloat(totalCountUnit) + parseFloat($scope.treatmentPlans["plans"][i].estimatedAmount);
					}

				}
				$scope.totalTreatmentPlanAmount = totalCountUnit;
			} catch (err) {
				document.getElementById("errMessage").innerHTML = err;
			}
		}

		$scope.addTreatmentPlan = function () {
			console.log("addTreatmentPlan called");

			flushToothSelector();

			if($scope.selectedPatient == "" || $scope.selectedPatient == null || typeof($scope.selectedPatient) == 'undefined'){
				var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Information',
					bodyText: 'Please select patient.' 
				};
				modalService.showModal({}, modalOptions).then(function (result) { });

				return false;
			}

			var treatmentPlanData = {};
			treatmentPlanData["caseNo"] = $scope.selectedPatient.patientId;
			console.log("treatmentPlans.plans" + JSON.stringify($scope.treatmentPlans));

			treatmentPlanData["plans"] = angular.copy($scope.treatmentPlans["plans"]);
			treatmentPlanData["totalAmount"] = $scope.totalTreatmentPlanAmount;

			var data = {};
			data["treatmentPlanData"] = treatmentPlanData;
			console.log("addTreatmentPlan variable value is " + JSON.stringify(data));
			manageTreatmentPlanService.addTreatmentPlanService(data, function (response) {
				console.log("Response from manageTreatmentPlanService.addTreatmentPlanService server is " + JSON.stringify(response));
				if (response.status == 'success') {
					$scope.treatmentPlans["plans"].length = 0;
					$scope.treatmentPlans["plans"].push({
						"treatment": "",
						"estimatedAmount": "",
						"upperLeftTooth": "",
						"upperRightTooth": "",
						"lowerLeftTooth": "",
						"lowerRightTooth": ""
					});
					$scope.totalTreatmentPlanAmount = "";
					$scope.refreshTreatmentPlanUnits();
					$scope.addplanButtonToggle = false;
					$scope.addTreatmentPlanBox = false;

					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		}

		$scope.clearTreatment = function () {
			flushToothSelector();
			$scope.treatmentPlans["plans"].length = 0;
			$scope.totalTreatmentPlanAmount = "";
			$scope.addTreatmentPlanBox = false;
		}

		function snackbarFunction() {
			var x = document.getElementById("snackbar");
			x.className = "show";
			setTimeout(function () {
				x.className = x.className.replace("show", "");
			}, 3000);
		}

		$scope.deletePlan = function (listName, index) {
			console.log("listName:: " + listName + " " + "index" + " " + index);
			$rootScope.deleteListName = listName;
			$rootScope.deleteIndex = index;
			var res = $rootScope.deleteListName.split(".");
			console.log("Value of res" + res);
			if (res.length > 1) {
				$scope[res[0]][res[1]].splice($rootScope.deleteIndex, 1);
			} else {
				$scope[$rootScope.deleteListName].splice($rootScope.deleteIndex, 1);
			}
			$rootScope.deleteListName = "";
			$rootScope.deleteIndex = "";

			for (var i = 0; i < $scope.treatmentPlans["plans"].length; i++) {
				$scope.planReadonly[i] = true;
			}

			$scope.highlightIndex = null;
			//$scope.treatmentPlanIndex = "";
			$scope.treatmentPlanIndex = 0;

			flushToothSelector();
		}

		$scope.editPlan = function (listName, index) {
			$scope.highlightIndex = index;
			flushToothSelector();
			console.log("length of plan is " + $scope.treatmentPlans["plans"].length);
			console.log("index to edit" + index);

			for (var i = 0; i < $scope.treatmentPlans["plans"].length; i++) {
				console.log("value of i" + i);
				console.log("value of index" + index);
				if (i == index) {
					$scope.planReadonly[i] = false;
					$scope.treatmentPlanIndex = index;

					var UL_array = $scope.treatmentPlans["plans"][index].upperLeftTooth.split(',');
					var a = {}
					for (var u = 0; u < UL_array.length; u++) {
						a["UL".concat(UL_array[u])] = true
					}

					var UR_array = $scope.treatmentPlans["plans"][index].upperRightTooth.split(',');
					for (var u = 0; u < UR_array.length; u++) {
						a["UR".concat(UR_array[u])] = true
					}


					var LL_array = $scope.treatmentPlans["plans"][index].lowerLeftTooth.split(',');
					for (var u = 0; u < LL_array.length; u++) {
						a["LL".concat(LL_array[u])] = true
					}


					var LR_array = $scope.treatmentPlans["plans"][index].lowerRightTooth.split(',');
					for (var u = 0; u < LR_array.length; u++) {
						a["LR".concat(LR_array[u])] = true
					}

					$scope.toothnumber = a;

				} else {
					console.log("reached to else");
					$scope.planReadonly[i] = true;
				}

			}

		}

		

		$scope.assignTreatmentData = function () {
			console.log("Assigned treatment plans Data is called");
			console.log("selectedPatient value is "+$rootScope.selectedPatientTreatmentList);
			var treatmentPlanLength = $rootScope.selectedPatientTreatmentList.length;
			console.log("treatmentPlanLength is "+treatmentPlanLength);
			$scope.ExistingTreatments["treatmentPlans"].length = 0;
			$scope.plans.length = 0;
			$scope.ActivePlansCount = 0;
			$scope.ClosedPlansCount = 0;
			for (i = 0; i < treatmentPlanLength; i++) {
				// var treatments = {};
				// var planListLength = $rootScope.selectedPatientTreatmentList[i].plans.length;
				// for (j = 0; j < planListLength; j++) {
				// 	$scope.plans.push($rootScope.selectedPatientTreatmentList[i].plans[j]);
				// 	$scope.manageTreatment["tp_id"] = $rootScope.selectedPatientTreatmentList[i].plans[j].tp_id;
				// }
				// treatments["total_amount"] = $rootScope.selectedPatientTreatmentList[i].total_amount;
				// treatments["status"] = $rootScope.selectedPatientTreatmentList[i].status;
				// treatments["tp_id"] =  $rootScope.selectedPatientTreatmentList[i].tp_id;
				// treatments["plans"] = $scope.plans;
				// treatments["treatment_start_date"] = $rootScope.selectedPatientTreatmentList[i].treatment_start_date;
				// treatments["treatment_end_date"] = $rootScope.selectedPatientTreatmentList[i].treatment_end_date;
				// $scope.ExistingTreatments["treatmentPlans"].push(treatments);
				// $scope.manageTreatment["patientId"] = $rootScope.selectedPatientTreatmentList[i].case_no;

				$scope.ExistingTreatments["treatmentPlans"][i] = $rootScope.selectedPatientTreatmentList[i]; 
				
				 if($scope.ExistingTreatments["treatmentPlans"][i].status == 'CLOSED'){
					$scope.ClosedPlansCount = $scope.ClosedPlansCount+1;
				 }else if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.ActivePlansCount = $scope.ActivePlansCount +1;
					$scope.manageTreatment["tp_id"] = $scope.ExistingTreatments["treatmentPlans"][i].tp_id;
					$scope.manageTreatment["patientId"] = $scope.ExistingTreatments["treatmentPlans"][i].case_no;
				 }
			}

			//$rootScope.selectedPatientTreatmentList
			if($rootScope.selectedPatientTreatmentList.length > 0 ){
				$scope.addplanButtonToggle = false;
				$scope.addTreatmentPlanBox = false;
				$scope.deleteTreatmentIcon = false;
			}

			if($scope.ActivePlansCount == 0){
				$scope.addplanButtonToggle = true;
				$scope.addTreatmentPlanBox = true;
			}
			
			// if($scope.ExistingTreatments["treatmentPlans"][0].status == 'CLOSED'){
			// 	console.log("inside status check if condition.");
			// 	$scope.applicantTab = 2;
			// 	$scope.addplanButtonToggle = true;
			// 	$scope.addTreatmentPlanBox = true;
			// 	$scope.deleteTreatmentIcon = true;
			// }else{
			// 	$scope.applicantTab = 1;
			// }

			$scope.deleteTreatmentIcon = true;

			console.log("Existing treatment plans are::"+JSON.stringify($scope.ExistingTreatments)); 
			console.log("manageTreatment >> "+JSON.stringify($scope.manageTreatment)); 

			$scope.getTreatments();
		}

		
		$scope.showTab = function (tab) {
			console.log("Show tab:" + tab);
			for (var i = 1; i <= 2; i++) {
			   $("#tab_" + i).hide();
			}
			$("#" + tab).show();

			if(tab=='tab_1'){
				$scope.applicantTab=1;
				$scope.addTreatmentPlanBox = true;
			}else if(tab=='tab_2'){
				$scope.applicantTab=2;
				$scope.addTreatmentPlanBox = false;
			}
			
		 }

		$scope.getTreatments = function () {
			console.log("$scope.manageTreatment value is " + JSON.stringify($scope.manageTreatment));
			var data = {};
			data["treatmentData"] = $scope.manageTreatment;
			manageTreatmentService.getTreatmentService(data, function (response) {
				console.log("Response from getTreatmentService is " + JSON.stringify(response));
				if (response.status == 'success') {
					$scope.treatmentList = response.data.treatmentsList;
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		}

		function sleep(milliseconds) {
			var start = new Date().getTime();
			for (var i = 0; i < 1e7; i++) {
			  if ((new Date().getTime() - start) > milliseconds){
				break;
			  }
			}
		  }

		$scope.editExistingTreatmentPlanPresent = function () {
			console.log("editExistingTreatmentPlanPresent called..");
			console.log("Value of ExistingTreatments.treatmentplans is "+JSON.stringify($scope.ExistingTreatments["treatmentPlans"]));
			$scope.addTreatmentPlanBox = true;
			$('#addEditBox')[0].focus();
			$scope.updateTrtplanButton = 1;
			$scope.treatmentPlans["plans"] = [];

			// var T_length = $scope.ExistingTreatments["treatmentPlans"].length;
			// for (i = 0; i < T_length; i++) {
		    //    console.log("Inside first loop")
			//    var plan_length = $scope.ExistingTreatments["treatmentPlans"][i];
			// 	for (j = 0; j < plan_length.plans.length; j++) {
			// 		var plansArray = $scope.ExistingTreatments["treatmentPlans"][i];
			// 		console.log("treatment  "+ plansArray);
			// 		$scope.treatmentPlans["plans"].push({
			// 			"tpu_id" : plansArray.plans[j].tpu_id,
			// 			"treatment": plansArray.plans[j].treatment,
			// 			"estimatedAmount": plansArray.plans[j].estimatedAmount,
			// 			"upperLeftTooth": plansArray.plans[j].upperLeftTooth,
			// 			"upperRightTooth": plansArray.plans[j].upperRightTooth,
			// 			"lowerLeftTooth":  plansArray.plans[j].lowerLeftTooth,
			// 			"lowerRightTooth": plansArray.plans[j].lowerRightTooth
			// 		});
			// 	}	
			// }

			var TP_length = $scope.ExistingTreatments["treatmentPlans"].length;
			for (i = 0; i < TP_length; i++) {
				if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.editableIndex = i;
					break;
				}
			}

			var activeTreatment = $scope.ExistingTreatments["treatmentPlans"][$scope.editableIndex];
			console.log("treatment  "+ activeTreatment);

			for(j=0; j < activeTreatment.plans.length ; j++){
				$scope.treatmentPlans["plans"].push({
					"tpu_id" : activeTreatment.plans[j].tpu_id,
					"treatment": activeTreatment.plans[j].treatment,
					"estimatedAmount": activeTreatment.plans[j].estimatedAmount,
					"upperLeftTooth": activeTreatment.plans[j].upperLeftTooth,
					"upperRightTooth": activeTreatment.plans[j].upperRightTooth,
					"lowerLeftTooth":  activeTreatment.plans[j].lowerLeftTooth,
					"lowerRightTooth": activeTreatment.plans[j].lowerRightTooth
				});
			}

			$scope.totalTreatmentPlanAmount = $scope.ExistingTreatments["treatmentPlans"][$scope.editableIndex].total_amount;
			console.log("value of treatmentPlans.Plans is  "+JSON.stringify($scope.treatmentPlans["plans"]));
		}
		
		function flushToothSelector() {
			$scope.upperLeft.length = 0;
			$scope.upperRight.length = 0;
			$scope.lowerLeft.length = 0;
			$scope.lowerRight.length = 0;
			$scope.toothnumber = {}; //FLUSHING
		}


		$scope.updateTreatmentPlan = function () {
			console.log("updateTreatmentPlan called..");
			
			// var treatmentPlanData = {};
			// treatmentPlanData["caseNo"] = $scope.selectedPatient.patientId;
			// console.log("treatmentPlans.plans" + JSON.stringify($scope.treatmentPlans));

			// treatmentPlanData["plans"] = angular.copy($scope.treatmentPlans["plans"]);
			// treatmentPlanData["totalAmount"] = $scope.totalTreatmentPlanAmount;

			var trtPlanJson = angular.toJson( $scope.treatmentPlans );

			console.log("Updating treatment plan :: " + trtPlanJson);
			console.log("Existing treatment is"+JSON.stringify($scope.ExistingTreatments));

			var treatmentPlanData = {};
			treatmentPlanData["caseNo"] = $scope.selectedPatient.patientId;
			treatmentPlanData["tp_id"] = $scope.ExistingTreatments["treatmentPlans"][$scope.editableIndex].tp_id; //This will need to be modified for multiple treatment plans.
			treatmentPlanData["totalAmount"] = $scope.totalTreatmentPlanAmount;
			$scope.treatmentPlans["plans"]["treatment"] = $scope.treatmentPlans.plans
			treatmentPlanData["plans"] = angular.copy($scope.treatmentPlans["plans"]);
			var data = {};
			data["treatmentPlanData"] = treatmentPlanData;
			console.log("Update TreatmentPlan variable values are " + JSON.stringify(data));
			manageTreatmentPlanService.updateTreatmentPlanService(data, function (response) {
				if (response.status == 'success') {
					$scope.refreshTreatmentPlanUnits();
					$scope.clearTreatment();
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Alert',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}

			 });
		}

		$scope.deleteTreatmentPlanPopUp = function (value) {
			console.log("value received from delete is ::"+JSON.stringify(value));

			$scope.deleteTreatmentPlanUnitId = value;
			console.log("$scope.deleteTreatmentPlanUnitId value is "+$scope.deleteTreatmentPlanUnitId);
			$('#deleteTreatmentPlanModal').modal('show');
		}

		$scope.deleteTreatmentPlan = function (value){
			if (value == 'delete') {
				$('#deleteTreatmentPlanModal').modal('hide');

        		var data = {};
				var treatmentPlanData = {};
				treatmentPlanData["tpu_id"] = $scope.deleteTreatmentPlanUnitId;
				data["plandata"] = treatmentPlanData;
				manageTreatmentPlanService.deleteTreatmentPlanService(data, function (response) {
					if (response.status == 'success') {
						$scope.refreshTreatmentPlanUnits();
						$scope.treatmentPlanIndex = 0;
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Information',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					} else if (response.status === "failed") {
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					}
				});

			} else if (value == 'cancel') {
				$('#deleteTreatmentPlanModal').modal('hide');
			}

			$scope.deleteTreatmentPlanId = '';
		}

		$scope.toggleAddTreatmentBox = function(){
			$scope.addTreatmentPlanBox = true;
			$('#addEditBox')[0].focus();
		}

		$scope.refreshTreatmentPlanUnits = function(){
			console.log("$rootScope.selectedPatientTreatmentList value is"+JSON.stringify($rootScope.selectedPatientTreatmentList));
			console.log("Existing treatment plans are::"+JSON.stringify($scope.ExistingTreatments));
			var searchData = {};
			searchData["search_by_option"] = "caseNo"// this will be default option during select patient.
			searchData["search_by_optionvalue"] = $rootScope.selectedPatient.patientId;
			var data = {};
			data["searchPatients"] = searchData
			console.log("data variable value is " + JSON.stringify(data));
			headerService.selectPatient(data, function (response) {
					console.log("Response from headerService.selectPatient server is " + JSON.stringify(response));
                if (response.status == 'success') {
					//$scope.selectedPatientTreatmentList.length = 0;
					$rootScope.selectedPatientTreatmentList  = response.data.treatmentPlanList;
					console.log("$rootScope.selectedPatientTreatmentList from refreshTreatmentPlanUnits :"+$rootScope.selectedPatientTreatmentList);
					if($rootScope.selectedPatientTreatmentList == "" || $rootScope.selectedPatientTreatmentList == null){
						$scope.addplanButtonToggle = true;
						$scope.updateTrtplanButton = 0;
						$scope.clearTreatment();
					}
					
					$scope.assignTreatmentData();
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }
			});
		}

		$scope.fetchTreatmentMaster = function () {
            console.log("fetchTreatmentMaster called");
			manageTreatmentPlanService.getTreatmentMasterService(function (response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					if(response.data.treatmentMasterList.length == 0){
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: "No Treatment is present!"
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
						$scope.treatmentMasterList = [];
					}else{
						$scope.treatmentMasterList = response.data.treatmentMasterList;
						$scope.treatmentsList = [];
						angular.forEach($scope.treatmentMasterList, function (value, key) {
							$scope.treatmentsList.push(value.treatment_name);
						});

						console.log("$scope.treatmentsList is "+ JSON.stringify($scope.treatmentsList));
					}
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }
			});

        };


		$scope.shiftTomanageTreatment = function (){
			$state.go('manageTreatment');
		};

		$scope.closedTreatmentPopUp = function (value){
			console.log("closedTreatmentPopUp called.");
			$('#closedTreatmentDetails').modal('show');
			$scope.closedTreatmentPlanID_IS = value;
			$scope.manageTreatment["tp_id"] = value;
			$scope.getTreatments();
		}


		function initialize() {
			console.log("manageTreatmentPlanController loaded");
			busyNotificationService.hideBusyIndicator();
			if (window.performance) { // this will change once login is started.
				console.info("window.performance works fine on this browser");
			}
			if (performance.navigation.type == 1) {
				console.info("This page is reloaded");
				$state.go('login');
			} else {
				console.info("This page is not reloaded");
			}

			$scope.treatmentPlans = {};
			$scope.treatmentPlans["plans"] = [];
			$scope.treatmentPlans["plans"].push({
				"treatment": "",
				"estimatedAmount": "",
				"upperLeftTooth": "",
				"upperRightTooth": "",
				"lowerLeftTooth": "",
				"lowerRightTooth": ""
			});

			$scope.applicantTab = 1;
			$scope.activeTab = 1;
			$scope.oldActiveTab = 1;

			$scope.toothnumber = {};
			$scope.upperLeft = [];
			$scope.upperRight = [];
			$scope.lowerLeft = [];
			$scope.lowerRight = [];
			$scope.treatmentPlanIndex = 0;
			$scope.planReadonly = [];
			$scope.planReadonly[0] = false;
			$scope.highlightIndex = null;
			$scope.plans = [];
			$scope.ExistingTreatments = {};
			$scope.ExistingTreatments["treatmentPlans"] = [];
			$scope.updateTrtplanButton = 0;
			$scope.manageTreatment = {};
			$scope.ActivePlansCount = 0;
			$scope.ClosedPlansCount = 0;

			if(checkEmptyField($scope.treatmentMasterList)){
				$scope.fetchTreatmentMaster();
			}	
			
			//console.log("$rootScope.selectedPatientTreatmentList check"+JSON.stringify($rootScope.selectedPatientTreatmentList));
			// if (!checkEmptyField($rootScope.selectedPatientTreatmentList)) {
			// 	if ($rootScope.selectedPatientTreatmentList.length > 0) {
			// 		console.log("calling assignTreatmentData");
			// 		$scope.assignTreatmentData();
			// 	}
			// }else{
			// 	$scope.addplanButtonToggle = true;
			// 	$scope.addTreatmentPlanBox = true;
			// 	$scope.deleteTreatmentIcon = true;
			// }
			
			
		}

		initialize();
	}
]);