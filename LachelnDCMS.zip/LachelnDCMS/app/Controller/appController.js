myApp.controller('AppCtrl', function ($scope, authentication) {

	

});
