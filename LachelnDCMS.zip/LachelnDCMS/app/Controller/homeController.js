myApp.controller('homeController', ['busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', 'appConstants', 'modalService', 'homeService',
function (busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, appConstants, modalService,homeService) {
	
	$scope.assignTreatmentData = function () {
		console.log("called from Home controller.");
		
	}

	

	function initialize(){
			console.log("Home Controller loaded");
			busyNotificationService.hideBusyIndicator(); // this will be commented once any function is called from here
	}

		initialize();
	}
]);
