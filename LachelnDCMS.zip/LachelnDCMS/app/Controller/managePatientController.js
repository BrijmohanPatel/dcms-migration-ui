myApp.controller('managePatientController', ['busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', '$stateParams', 'appConstants', 'modalService', 'homeService', 'managePatientService',
    function (busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, $stateParams, appConstants, modalService, homeService, managePatientService) {

		function showModalPopUp(message){
			var modalOptions = {
				isCloseEnabled: false,
				headerText: 'Information',
				bodyText: message
			};
			modalService.showModal({}, modalOptions).then(function (result) { });
		}

        $scope.chooseDoctor = function () {
            console.log("chooseDoctor called");
        }

		$scope.getPatients = function () {
            console.log("getPatients called");
			managePatientService.getAllPatientsService(function (response) {
				console.log("Response received:", JSON.stringify(response));
				if (response.status == 'success') {
					if(response.data.patientsList.length == 0){
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					}else{
						$scope.patientsList = response.data.patientsList;
					}
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }


			});

        }
		
		$scope.savePatientDetails = function () {
			console.log("savePatientDtails called");
			console.log("managPatient Details: "+JSON.stringify($scope.managePatients));
			console.log("managPatient Date: "+ document.getElementById("todaysPatientDate").value);
			
			if(checkEmptyField(document.getElementById("todaysPatientDate").value)){
				showModalPopUp("Please select Date");
				return false;
			}
			
			if(checkEmptyField($scope.managePatients.patientName)){
				showModalPopUp("Please enter patient name");
				return false;
			}
			
			if(checkEmptyField($scope.managePatients.patientGender)){
				showModalPopUp("Please select patientGender");
				return false;
			}
			
			if(checkEmptyField($scope.managePatients.patientMobileNumber)){
				showModalPopUp("Please enter mobile number");
				return false;
			}
			
			$scope.managePatients["patientRegistrationDate"] = fromddmmyyyy_to_yyyymmdd(document.getElementById("todaysPatientDate").value);
			
			var data = {};
            data["patientDTO"] = $scope.managePatients;
            console.log("data variable value is " + JSON.stringify(data));
			
			managePatientService.addPatientService(data, function (response) {
				 console.log("Response from server is " + JSON.stringify(response));
                if (response.status == 'success') {
					$scope.managePatients = {};
					document.getElementById("todaysPatientDate").value = "";
					$rootScope.selectedPatient = response.data.patientdata;
					$state.go('manageTreatmentPlan');
						var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Information',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                        };
                        modalService.showModal({}, modalOptions).then(function (result) { });
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }
			});
		}

		$scope.assignTreatmentData = function () {
			console.log("Assigned treatment plans Data is called");
			console.log("selectedPatient value is "+$rootScope.selectedPatientTreatmentList);
			var treatmentPlanLength = $rootScope.selectedPatientTreatmentList.length;
			console.log("treatmentPlanLength is "+treatmentPlanLength);
			$scope.ExistingTreatments["treatmentPlans"].length = 0;
			$scope.plans.length = 0;
			$scope.ActivePlansCount = 0;
			$scope.ClosedPlansCount = 0;
			for (i = 0; i < treatmentPlanLength; i++) {
				$scope.ExistingTreatments["treatmentPlans"][i] = $rootScope.selectedPatientTreatmentList[i]; 
				
				 if($scope.ExistingTreatments["treatmentPlans"][i].status == 'CLOSED'){
					$scope.ClosedPlansCount = $scope.ClosedPlansCount+1;
				 }else if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.currentPlanTotalAmount = $rootScope.selectedPatientTreatmentList[i].total_amount;
					$scope.ActivePlansCount = $scope.ActivePlansCount +1;
					$scope.manageTreatment["tp_id"] = $scope.ExistingTreatments["treatmentPlans"][i].tp_id;
					$scope.manageTreatment["patientId"] = $scope.ExistingTreatments["treatmentPlans"][i].case_no;
				 }
			}

			if($rootScope.selectedPatientTreatmentList.length > 0 ){
				$scope.addplanButtonToggle = false;
				$scope.addTreatmentPlanBox = false;
				$scope.deleteTreatmentIcon = false;
			}

			if($scope.ActivePlansCount == 0){
				$scope.addplanButtonToggle = true;
				$scope.addTreatmentPlanBox = true;
			}
			
			$scope.deleteTreatmentIcon = true;

			console.log("Existing treatment plans are::"+JSON.stringify($scope.ExistingTreatments)); 
			console.log("manageTreatment >> "+JSON.stringify($scope.manageTreatment)); 

			var TP_length = $scope.ExistingTreatments["treatmentPlans"].length;
			for (i = 0; i < TP_length; i++) {
				if($scope.ExistingTreatments["treatmentPlans"][i].status == 'ACTIVE'){
					$scope.editableIndex = i;
					break;
				}
			}
		}

        function snackbarFunction() {
            var x = document.getElementById("snackbar");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
        }

		$scope.deletePatientPopUp = function (value, index) {
            console.log("clicked value index is " + index);
            $('#deletePatientModal').modal('show');
            $scope.deletePatientIndex = index;

        }

		$scope.deletePatient = function (value) {
			console.log("deletePatient called");
			if (value == 'delete') {
				var patientdata = {};
				patientdata["patientId"] = $scope.patientsList[$scope.deletePatientIndex].patientId;
				var data = {};
                data["patientdata"] = patientdata;
				managePatientService.deletePatientService(data, function (response) {
					console.log(JSON.stringify(response));
					if (response.status == 'success') {
                        var serverResponse = response;
                        if (serverResponse.status == "success") {
                            $scope.deleteMessage = serverResponse.message;
                            $('#deletePatientModal').modal('hide');
                            //snackbarFunction();
                            $scope.deletePatientIndex = "";
							$scope.getPatients();
                        }
                    } else if (response.status === "failed") {
						$('#deletePatientModal').modal('hide');
                        var modalOptions = {
                            isCloseEnabled: false,
                            headerText: 'Information',
                            bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                        };
                        $scope.deletePatientIndex = "";
                    }
					$scope.deletePatientIndex = "";
				}); 
			} else if (value == 'cancel') {
				$('#deletePatientModal').modal('hide');
               $scope.deletePatientIndex = "";
			}

           
        }

		$scope.editPatientPopUp = function (value, index) {
            console.log("clicked value index is " + index);
            $('#editPatientModal').modal('show');
            $scope.editPatientIndex = index;
        }

		$scope.editPatientData = function (value) {
            console.log("editPatientData called");
			var index = $scope.editPatientIndex;	
			if (value == 'edit') {
				$scope.addPatientToggle = false;
				$scope.editPatientToggle = true;
				console.log("clicked value index is " + index);
				document.getElementById("patientBox").style.boxShadow = "-3px -7px 17px 0px rgba(0,63,250,0.61)";
				$(window).scrollTop(0);

				document.getElementById("todaysPatientDate").value = $scope.patientsList[index].patientRegistrationDate;

				$scope.managePatients.patientId = $scope.patientsList[index].patientId;
				$scope.managePatients.patientName = $scope.patientsList[index].patientName;
				$scope.managePatients.patientGender = $scope.patientsList[index].patientGender;
				$scope.managePatients.patientMobileNumber = $scope.patientsList[index].patientMobileNumber;
				$scope.managePatients.patientAge = $scope.patientsList[index].patientAge;
				$scope.managePatients.patientOccupation = $scope.patientsList[index].patientOccupation;
				$scope.managePatients.patientAddress = $scope.patientsList[index].patientAddress;
				$scope.managePatients.patientMedicalHistory = $scope.patientsList[index].patientMedicalHistory;
				$scope.managePatients.patientChiefComplaint = $scope.patientsList[index].patientChiefComplaint;
				$scope.managePatients.patientIntraOralExamination = $scope.patientsList[index].patientIntraOralExamination;


				$('#editPatientModal').modal('hide');
               	$scope.editPatientIndex = "";

			}else if(value == 'cancel'){
				$('#editPatientModal').modal('hide');
               	$scope.editPatientIndex = "";
			}
        }

		$scope.updatePatient = function () {
            console.log("updatePatient called");
			var data = {};
			$scope.managePatients.patientRegistrationDate = document.getElementById("todaysPatientDate").value;
			data["patientdata"] = $scope.managePatients;
			console.log("updating patient data::"+ JSON.stringify($scope.managePatients));
			managePatientService.editPatientService(data, function (response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					var serverResponse = response;
					if (serverResponse.status == "success") {
						$scope.clearEditPatient();
						$scope.getPatients();
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Information',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					}
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			}); 
        }

		$scope.clearEditPatient = function () {
            document.getElementById("patientBox").style.boxShadow = "";
            $scope.addPatientToggle = true;
            $scope.editPatientToggle = false;
			$scope.editPatientIndex = "";
			document.getElementById("todaysPatientDate").value = "";
			$scope.managePatients.patientName = "";
			$scope.managePatients.patientGender = "";
			$scope.managePatients.patientMobileNumber = "";
			$scope.managePatients.age = "";
			$scope.managePatients.patientOccupation = "";
			$scope.managePatients.patientAddress = "";
			$scope.managePatients.patientMedicalHistory = "";
			$scope.managePatients.patientChiefComplaint = "";
			$scope.managePatients.patientIntraOralExamination = "";
        }

        function initialize() {
            console.log("Manage Patient controller loaded");
            busyNotificationService.hideBusyIndicator();
            //busyNotificationService.showBusyIndicator();
            if (window.performance) { // this will change once login is started.
                //console.info("window.performance works fine on this browser");
            }
            if (performance.navigation.type == 1) {
                //console.info("This page is reloaded");
                $state.go('login');
            } else {
                //console.info("This page is not reloaded");
            }

			$scope.addPatientToggle = true;
			$scope.editPatientToggle = false;
			$scope.managePatients  = {};
			$scope.patientsList = [];
			$scope.manageTreatment = {};
			$scope.manageTreatment["toothData"] = {};
			$scope.ExistingTreatments = {};
			$scope.ExistingTreatments["treatmentPlans"] = [];
			$scope.plans = [];
			$scope.selectedPatient = {};
        }


        initialize();
    }
]);