myApp.controller('applicationController', ['busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', 'appConstants', 'modalService',
	function (busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, appConstants, modalService) {

		initialize();

		function initialize(){
			console.log("applicationController loaded");
		}
	}
]);
