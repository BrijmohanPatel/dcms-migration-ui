myApp.controller('loginController', ['busyNotificationService', 'modalService', '$scope', '$location', '$window', '$rootScope', '$state', '$controller', '$uibModal', 'appConstants', 'AuthenticationService',
	function (busyNotificationService, modalService, $scope, $location, $window, $rootScope, $state, $controller, $uibModal, appConstants, AuthenticationService) {

			$(document).keypress(function(e) {
			    if(e.which == 13) {
			      if($scope.emailId != null  && $scope.password !=null){
							$scope.verifyCredentials();
					}
			    }
			});
			
			
			
			$scope.login = function(){
				//Commenting below, can be modified later.
				/*console.log("login called");
				if($scope.userId =="" || $scope.password=="" || $scope.userId == undefined || $scope.password== undefined || $scope.userId == null || $scope.password== null){
					$scope.loginMessage = "Please enter USERID AND PASSWORD!!";
					snackbarFunction();
					return;
				}
				var data = {};
				data["userName"] =  $scope.userId;
				data["password"] =  $scope.password;
				AuthenticationService.login(data, function (response) {
				 console.log("Response from server is " + JSON.stringify(response));
					if (response.status == "success") {
						$rootScope.globals = {}
						$rootScope.globals.loggedInUser = response.data.userName;						
						$state.go("home");
					}else{
						$scope.loginMessage = response.message;
						snackbarFunction();
						return;
					}
				});
				*/
				
				if($scope.userId == 'admin' || $scope.password == 'admin'){
					$state.go("admin");
				}else{
					$state.go("home");
				}
			}
			
			function initialize() {
				console.log("loginController.init()");
				busyNotificationService.hideBusyIndicator();
			}

			initialize();
	}
]);
