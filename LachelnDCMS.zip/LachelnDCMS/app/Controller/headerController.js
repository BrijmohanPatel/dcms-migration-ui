myApp.controller('headerController', ['headerService','busyNotificationService', 'modalService', '$scope', '$location', '$window', '$rootScope', '$state', '$controller', '$uibModal', 'appConstants', 'AuthenticationService',
function (headerService,busyNotificationService, modalService, $scope, $location, $window, $rootScope, $state, $controller, $uibModal, appConstants, AuthenticationService) {

			$scope.signout = function(){
				console.log("headerController.signout()");
				$rootScope.globals.loggedInUser = "";
				$state.go("login");
			};
			
			$scope.searchPatientBox = function(){
				$('#searchPatientModal').modal('show');
			}
			
			$scope.searchPatient = function () {
			console.log("searchPatient called");

			if (checkEmptyField($scope.searchByOption)) {
				showModalPopUp("Please select searchBy Option");
				return false;
			}

			if ($scope.searchByOption == 'Date') {

				if (checkEmptyField(document.getElementById("startDateID").value)) {
					showModalPopUp("Please select start Date");
					return false;
				}

				if (checkEmptyField(document.getElementById("endDateID").value)) {
					showModalPopUp("Please select end Date");
					return false;
				}

				var searchDate = {}
				searchDate["startDate"] = fromddmmyyyy_to_yyyymmdd(document.getElementById("startDateID").value)
				searchDate["endDate"] = fromddmmyyyy_to_yyyymmdd(document.getElementById("endDateID").value)

			} else {
				if (checkEmptyField($scope.searchByOptionValue)) {
					showModalPopUp("Please enter " + $scope.searchByOption);
					return false;
				}
			}

			var searchData = {};
			searchData["searchByOption"] = $scope.searchByOption
			searchData["searchByOptionValue"] = $scope.searchByOptionValue

			if ($scope.searchByOption == 'Date') {
				searchData["searchByDate"] = searchDate
			}

			var data = {};
			data["patientDTO"] = searchData
			console.log("data variable value is " + JSON.stringify(data));
			headerService.searchPatientService(data, function (response) {
				console.log("Response from server is " + JSON.stringify(response));
                if (response.status == 'success') {
					if(response.data.patientsList.length == 0){
						$scope.searchedPatientsList.length = 0;
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					}else{
						$scope.searchedPatientsList = response.data.patientsList;
						console.log("searched patient list"+JSON.stringify($scope.searchedPatientsList));
						angular.forEach($scope.searchedPatientsList, function (value, key) {
							console.log("forEach"+key+JSON.stringify(value));
							$scope.searchedPatientsList[key].patientRegistrationDate = extractDateFromISOString($scope.searchedPatientsList[key].patientRegistrationDate);
						});
						console.log("searched patient list after date modification."+JSON.stringify($scope.searchedPatientsList));
					}
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }
			});
		}
		
		$scope.selectPatient = function (listName, index) {
			console.log("selectPatient called");
			console.log("selcted index value is"+index);
			console.log("selected value is  "+JSON.stringify($scope.searchedPatientsList[index]));
			$rootScope.selectedPatient = angular.copy($scope.searchedPatientsList[index]);
			//console.log("$rootScope.selectedPatient ::"+ JSON.stringify($rootScope.selectedPatient));
			$('#searchPatientModal').modal('hide');
			var searchData = {};
			searchData["search_by_option"] = "caseNo"// this will be default option during select patient.
			searchData["search_by_optionvalue"] = $rootScope.selectedPatient.patientId;
			var data = {};
			data["searchPatients"] = searchData
			console.log("data variable value is " + JSON.stringify(data));
			headerService.selectPatient(data, function (response) {
				console.log("Response from headerService.selectPatient server is " + JSON.stringify(response));
                if (response.status == 'success') {
					//$scope.selectedPatientTreatmentList.length = 0;
					$rootScope.selectedPatientTreatmentList  = response.data.treatmentPlanList;
					$scope.assignTreatmentData();
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }
			});	
		}

			function initialize() {
				console.log("headerController initialize() called");
				$scope.searchedPatientsList = [];
				$scope.selectedPatient = {};
				$scope.selectedPatientTreatmentList = [];
			}
			initialize();
		}
	]);
