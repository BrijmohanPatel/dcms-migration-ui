myApp.controller('adminController', ['busyNotificationService', '$scope', '$filter', '$location', '$window', '$rootScope', '$state', 'appConstants', 'modalService', 'adminAddTreatmentService', 'adminAddWorkdoneService',
	function (busyNotificationService, $scope, $filter, $location, $window, $rootScope, $state, appConstants, modalService, adminAddTreatmentService, adminAddWorkdoneService) {

		initialize();


		$scope.saveTreatmentName = function (){
			console.log("save Treatment function is called !");
			if($scope.treatmentName == "" || $scope.treatmentName == null || $scope.treatmentName == undefined){
				var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Information',
					bodyText: "Please enter Treatment Name"
				};
				modalService.showModal({}, modalOptions).then(function (result) { });
				return false;
			}
			var data = {}
			var trtData = {}
			trtData["treatment_name"] = $scope.treatmentName;
			data["treatmentMasterData"] = trtData;
			console.log("treatment Data is"+JSON.stringify(data));
			adminAddTreatmentService.saveTreatmentMaster(data, function (response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					$scope.treatmentName = "";
					$scope.getTreatmentMaster();
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		};

		$scope.editTreatmentMaster = function(value){
			console.log("Selected edit treatment master"+value);
			$scope.treatmentName = $scope.treatmentMasterList[value].treatment_name;
			$scope.tm_id = $scope.treatmentMasterList[value].tm_id;
			document.getElementById("AddTreatmentBox").style.boxShadow = "-3px -7px 17px 0px rgba(0,63,250,0.61)";
			$scope.showUpdateButtons = true;
			$scope.showSaveButtons = false;
			$scope.editTreatmentMasterIndex = value;
		}

		$scope.clearTreatmentMaster = function(){
			document.getElementById("AddTreatmentBox").style.boxShadow = "";
			$scope.showUpdateButtons = false;
			$scope.showSaveButtons = true;
			$scope.treatmentName = "";
			$scope.tm_id = "";
			$scope.editTreatmentMasterIndex = "";
		}

		$scope.updateTreatmentMaster = function (){
			console.log("update Treatment function is called !");
			var data = {}
			var trtData = {}
			trtData["treatment_name"] = $scope.treatmentName;
			trtData["tm_id"] =  $scope.treatmentMasterList[$scope.editTreatmentMasterIndex].tm_id;
			data["treatmentMasterData"] = trtData;
			console.log("treatment Data is"+JSON.stringify(data));
			adminAddTreatmentService.updateTreatmentMaster(data, function (response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					$scope.clearTreatmentMaster();
					$scope.getTreatmentMaster();
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		}

		$scope.getTreatmentMaster = function () {
            console.log("getTreatmentMaster called");
			adminAddTreatmentService.getTreatmentMasterService(function (response) {
				console.log(JSON.stringify(response));

				if (response.status == 'success') {
					if(response.data.treatmentMasterList.length == 0){
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: "No Treatment is present!"
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
						$scope.treatmentMasterList = [];
					}else{
						$scope.treatmentMasterList = response.data.treatmentMasterList;
					}
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }
			});

        };


		$scope.deleteTreatmentMaster = function (value) {
			console.log("deleteTreatmentMaster called"+value);
				var treatmentData = {};
				treatmentData["tm_id"] = $scope.treatmentMasterList[value].tm_id;
				var data = {};
                data["treatmentMasterData"] = treatmentData;
				adminAddTreatmentService.deleteTreatmentMasterService(data, function (response) {
					console.log(JSON.stringify(response));
					if (response.status == 'success') {
                        var serverResponse = response;
                        if (serverResponse.status == "success") {
							$scope.getTreatmentMaster();
							var modalOptions = {
								isCloseEnabled: false,
								headerText: 'Information',
								bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
							};
							modalService.showModal({}, modalOptions).then(function (result) { });
                        }
                    } else if (response.status === "failed") {
						$('#deletePatientModal').modal('hide');
                        var modalOptions = {
                            isCloseEnabled: false,
                            headerText: 'Information',
                            bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                        };
                        $scope.deletePatientIndex = "";
                    }
					$scope.deletePatientIndex = "";
				}); 
        };


		// add workdone master codes.

		$scope.saveworkdoneName = function() {
			console.log("save Workdone function is called !");
			if ($scope.workdoneName == "" || $scope.workdoneName == null || $scope.workdoneName == undefined) {
				var modalOptions = {
					isCloseEnabled: false,
					headerText: 'Information',
					bodyText: "Please enter workdone Name"
				};
				modalService.showModal({}, modalOptions).then(function(result) {});
				return false;
			}
			var data = {}
			var wkrDoneData = {}
			wkrDoneData["workdone_name"] = $scope.workdoneName;
			data["workdoneMasterData"] = wkrDoneData;
			console.log("Workdone Data is" + JSON.stringify(data));
			adminAddWorkdoneService.saveWorkdoneMaster(data, function(response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					$scope.workdoneName = "";
					$scope.getWorkdoneMaster(); 
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function(result) {});
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function(result) {});
				}
			});
		};

		$scope.deleteWorkdoneMaster = function(value){
			console.log("deleteWorkdoneMaster called"+ value);
			var WorkdoneData = {};
			WorkdoneData["wd_id"] = $scope.workdoneMasterList[value].w_id;
			var data = {};
			data["workdoneMasterData"] = WorkdoneData;
			adminAddWorkdoneService.deleteWorkdoneMasterService(data, function (response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					var serverResponse = response;
					if (serverResponse.status == "success") {
						$scope.getWorkdoneMaster();
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Information',
							bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
					}
				} else if (response.status === "failed") {
					$('#deletePatientModal').modal('hide');
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					$scope.deletePatientIndex = "";
				}
				$scope.deletePatientIndex = "";
			}); 

		}

		$scope.editWorkdoneMaster = function (value){
			console.log("Selected edit work master ::"+value);
			$scope.workdoneName = $scope.workdoneMasterList[value].work_name;
			$scope.w_id = $scope.workdoneMasterList[value].w_id;
			document.getElementById("AddWorkDoneBox").style.boxShadow = "-3px -7px 17px 0px rgba(0,63,250,0.61)";
			$scope.showUpdateButtons = true;
			$scope.showSaveButtons = false;
			$scope.editWorkMasterIndex = value;
		}

		$scope.clearWorkdone = function (){
			document.getElementById("AddWorkDoneBox").style.boxShadow = "";
			$scope.showUpdateButtons = false;
			$scope.showSaveButtons = true;
			$scope.workdoneName = "";
			$scope.w_id = "";
			$scope.editWorkMasterIndex = "";
		}

		$scope.getWorkdoneMaster = function (){
			console.log("getWorkdoneMaster called");
			adminAddWorkdoneService.getWorkdoneMasterService(function (response) {
			console.log("Response from the server is "+JSON.stringify(response));
				if (response.status == 'success') {
					if(response.data.workdoneMasterList.length == 0){
						var modalOptions = {
							isCloseEnabled: false,
							headerText: 'Alert',
							bodyText: "No Work is present!"
						};
						modalService.showModal({}, modalOptions).then(function (result) { });
						$scope.workdoneMasterList = [];
					}else{
						$scope.workdoneMasterList = response.data.workdoneMasterList;
					}
				}else if (response.status === "failed") {
                    var modalOptions = {
                        isCloseEnabled: false,
                        headerText: 'Alert',
                        bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
                    };
					modalService.showModal({}, modalOptions).then(function (result) { });
                }

			});
		};

		$scope.updateWorkDoneMaster = function (){
			console.log("update Work done function is called !");
			var data = {}
			var wrkData = {}
			wrkData["workdone_name"] = $scope.workdoneName;
			wrkData["wd_id"] =  $scope.workdoneMasterList[$scope.editWorkMasterIndex].w_id;
			data["workdoneMasterData"] = wrkData;
			console.log("Work Data is"+JSON.stringify(data));
			adminAddWorkdoneService.updateWorkDoneMaster(data, function (response) {
				console.log(JSON.stringify(response));
				if (response.status == 'success') {
					$scope.clearWorkdone();
					$scope.getWorkdoneMaster();
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				} else if (response.status === "failed") {
					var modalOptions = {
						isCloseEnabled: false,
						headerText: 'Information',
						bodyText: (response.message == undefined || response.message == null || response.message == "") ? 'There has been some internal issue.' : response.message
					};
					modalService.showModal({}, modalOptions).then(function (result) { });
				}
			});
		}


		function initialize(){
			console.log("adminController loaded");
			$scope.showUpdateButtons = false;
			$scope.showSaveButtons = true;
		}
	}
]);
