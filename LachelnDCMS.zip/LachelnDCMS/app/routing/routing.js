myApp.config(function ($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise("login");
  $stateProvider
  .state('login', {
    url: "/login",
    controller: "loginController",
    templateUrl: "app/Views/login.html"
  })
  .state('home', {
    url: "/home",
    controller: "homeController",
    templateUrl: "app/Views/home.html"
  })
  .state('managePatient', {
    url: "/managePatient",
    controller: "managePatientController",
    templateUrl: "app/Views/managePatient.html",
	params: {
                data: null
            }
  })
  .state('manageTreatmentPlan', {
    url: "/manageTreatmentPlan",
    controller: "manageTreatmentPlanController",
    templateUrl: "app/Views/manageTreatmentPlan.html",
	params: {
                data: null
            }
  })
  .state('manageTreatment', {
    url: "/manageTreatment",
    controller: "manageTreatmentController",
    templateUrl: "app/Views/manageTreatment.html",
	params: {
                data: null
            }
  })
  .state('caseReport', {
    url: "/caseReport",
    controller: "caseReportController",
    templateUrl: "app/Views/caseReport.html",
	params: {
                data: null
            }
  })
  .state('header', {
    url: "/header",
    controller: "headerController",
    templateUrl: "app/Views/header.html"
  })
  .state('ledger', {
    url: "/ledger",
    controller: "headerController",
    templateUrl: "app/Views/LedgerBill.html"
  })
  .state('admin', {
    url: "/admin",
    controller: "adminController",
    templateUrl: "app/Views/Admin/adminHome.html"
  })
  .state('addTreatment', {
    url: "/addTreatment",
    controller: "adminController",
    templateUrl: "app/Views/Admin/addTreatment.html"
  })
  .state('addWorkdone', {
    url: "/addWorkdone",
    controller: "adminController",
    templateUrl: "app/Views/Admin/addWorkdone.html"
  })
 });
