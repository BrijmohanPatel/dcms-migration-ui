myApp.factory('interceptorService', ['busyNotificationService', 'modalService', '$http', '$state', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'localconfig', 'serverconfig', 'appConstants',
function (busyNotificationService, modalService, $http, $state, $cookieStore, $rootScope, $timeout, config, cryptoService, localconfig, serverconfig, appConstants) {
  var service = {};
  var appEnvironment = '';
  var errorResponse = {
    "status": "failed"
  };

  initialize();

  function initialize() {
    console.log("interceptorService.initialize()");
    if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
      appEnvironment = localconfig;
    } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
      appEnvironment = serverconfig;
    }
  }




  service.encapsulateRequest = function (req) {
    console.log("interceptorService.encapsulateRequest()");
    var request = {};
    request = JSON.stringify(req);
    console.log("encapsulateRequest request data :"+request);


    return request;

    /*
    //Add CryptoService
    if(req.data == undefined || req.data == null){
    req.data = {};
  }

  //validParams (req tampering)
  var validParams = {};
  for(key in req){
  if(key != "data"){
  validParams[key] = req[key];
}
}
req["data"]["validParams"] = validParams;


var encData = cryptoService.encrypt(req.data);
req.iv = encData.iv;
req.salt = encData.salt;
req.data = encData.data;
return req;*/
};

service.apiCall = function(config, callback){
  console.log("interceptorService.apiCall()");
  busyNotificationService.showBusyIndicator();
  $http(config).success(function (response){
    busyNotificationService.hideBusyIndicator();
    if(response.status == "failed" && response.statusCode == "9999" && $rootScope.globals.regType != 4){
      var modalOptions = {
        isCloseEnabled: false,
        headerText: 'Information',
        bodyText: response.message
      };
      modalService.showModal({}, modalOptions).then(function (result) {
            $state.go("login");
      });

    }else if(response.status == "failed" && response.statusCode == "9999" && $rootScope.globals.regType == 4){
      var modalOptions = {
        isCloseEnabled: false,
        headerText: 'Information',
        bodyText: response.message
      };
      modalService.showModal({}, modalOptions).then(function (result) {});
      $state.go("cpanel");
    }
    callback(response);
  }).error(function (data, status) {
    busyNotificationService.hideBusyIndicator();
    callback(errorResponse);
  });

  //$http(config).success(function (response) {
  /*$rootScope.sessionTime = (Number(response.data.sessionTimeout == undefined || response.sessionTimeout == null ? ($rootScope.sessionTime / 60000) : response.sessionTimeout) * 60000);
  $rootScope.$broadcast('clearTimer', {data:{}});
  busyNotificationService.hideBusyIndicator();
  if($rootScope.globals.currentUser == undefined || $rootScope.globals.currentUser == null)
  $rootScope.globals.currentUser = {};
  $rootScope.globals.currentUser.accessToken = response.accessToken == undefined || response.accessToken == null ? $rootScope.globals.currentUser.accessToken : response.accessToken;*/
  //	callback(response);
  //}).error(function (response) {
  //	$rootScope.sessionTime = (Number(response.sessionTimeout == undefined || response.sessionTimeout == null ? ($rootScope.sessionTime / 60000) : response.sessionTimeout) * 60000);
  //	$rootScope.$broadcast('clearTimer', {data:{}});
  //    busyNotificationService.hideBusyIndicator();
  //    callback(response);
  //});
}

return service;
}]);
