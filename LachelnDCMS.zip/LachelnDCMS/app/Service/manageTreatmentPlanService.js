myApp.factory('manageTreatmentPlanService', ['busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig', 'appConstants',
    function(busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, manageTreatmentPlanService) {

        var service = {};
        var appEnvironment = '';

        service.searchPatientService = function(data, callback) {
            console.log("manageTreatmentPlanService.searchPatientService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.SEARCH_PATIENT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };
		
		service.addTreatmentPlanService = function(data, callback) {
          console.log("manageTreatmentPlanService.addTreatmentPlanService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.ADD_TREATMENT_PLAN_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };

        service.getTodaysWorkService = function(data, callback) {
            console.log("manageTreatmentPlanService.getTodaysWorkService()" + JSON.stringify(data));
            var dataObj = {};
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "getTodaysWork";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            busyNotificationService.showBusyIndicator();
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
			//busyNotificationService.LOAD();
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_TODAYS_WORK,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };


        service.fetchBillService = function(data, callback) {
            console.log("manageTreatmentPlanService.fetchBillService()" + JSON.stringify(data));
            var dataObj = {};
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "fetchBill";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            busyNotificationService.showBusyIndicator();
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
			//busyNotificationService.LOAD();
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.FETCH_BILL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
				//busyNotificationService.UNLOAD();
                callback(response);
            });
        };
		
		service.downloadPDFService = function(data, callback) {
            console.log("manageTreatmentPlanService.downloadPDFService()" + JSON.stringify(data));
            var dataObj = {};
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "generatePDF";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            busyNotificationService.showBusyIndicator();
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);

            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GENERATE_PDF,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };
		
		service.deleteTreatmentPlanService = function(data, callback) {
            console.log("manageTreatmentPlanService.deleteTreatmentPlanService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "deleteTreatmentPlan";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.DELETE_TREATMENT_PLAN_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };
		
		service.updateTreatmentPlanService = function(data, callback) {
            console.log("manageTreatmentPlanService.updateTreatmentPlanService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "updateTreatmentPlan";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.UPDATE_TREATMENT_DATA_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };

        service.getTreatmentMasterService = function(callback) {
            console.log("manageTreatmentPlanService.getTreatmentMasterService()");
            busyNotificationService.showBusyIndicator();
            var config = {
                method: appEnvironment.METHOD_GET,
                url: appEnvironment.GET_TREATMENT_MASTER_URL
            };
            //busyNotificationService.LOAD();
            interceptorService.apiCall(config, function(response) {
                //busyNotificationService.UNLOAD();
                callback(response);
                
            });
        };


        function initialize() {
            console.log("manageTreatmentPlanService.initialize()");
            if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
                appEnvironment = localconfig;
            } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
                appEnvironment = serverconfig;
            }
        }

        initialize();

        return service;
    }
]);