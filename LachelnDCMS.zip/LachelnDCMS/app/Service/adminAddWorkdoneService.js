myApp.factory('adminAddWorkdoneService', [ 'busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig',  'appConstants',
function (busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, adminAddTreatmentService) {

  var service = {};
  var appEnvironment = '';

    service.saveWorkdoneMaster = function(data, callback) {
        console.log("adminAddWorkdoneService.saveWorkdoneMaster()" + JSON.stringify(data));
        var dataObj = {};
        busyNotificationService.showBusyIndicator();
        dataObj["status"] = "";
        dataObj["message"] = "";
        dataObj["userName"] = null;
        dataObj["statusCode"] = "";
        dataObj["action"] = "saveWorkDone";
        dataObj["userCode"] = null;
        dataObj["userId"] = 0;
        dataObj["accessToken"] = null;
        dataObj["mobile"] = null;
        dataObj["email"] = null;
        dataObj["data"] = data;
        dataObj = interceptorService.encapsulateRequest(dataObj);
        console.log("final Request is " + dataObj);
        var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.SAVE_WORKDONE_MASTER__URL,
            data: dataObj
        };
        //busyNotificationService.LOAD();
        interceptorService.apiCall(config, function(response) {
            //busyNotificationService.UNLOAD();
            callback(response);
            
        });
    };

    service.getWorkdoneMasterService = function(callback) {
        console.log("adminAddWorkdoneService.getWorkdoneMasterService()");
        busyNotificationService.showBusyIndicator();
        var config = {
            method: appEnvironment.METHOD_GET,
            url: appEnvironment.GET_WORKDONE_MASTER_URL
        };
        //busyNotificationService.LOAD();
        interceptorService.apiCall(config, function(response) {
            //busyNotificationService.UNLOAD();
            callback(response);
            
        });
    };


    service.deleteWorkdoneMasterService = function(data, callback) {
        console.log("adminAddWorkdoneService.deleteWorkdoneMasterService()" + JSON.stringify(data));
        var dataObj = {};
        busyNotificationService.showBusyIndicator();
        dataObj["status"] = "";
        dataObj["message"] = "";
        dataObj["userName"] = null;
        dataObj["statusCode"] = "";
        dataObj["action"] = "deleteWorkMaster";
        dataObj["userCode"] = null;
        dataObj["userId"] = 0;
        dataObj["accessToken"] = null;
        dataObj["mobile"] = null;
        dataObj["email"] = null;
        dataObj["data"] = data;
        dataObj = interceptorService.encapsulateRequest(dataObj);
        console.log("final Request is " + dataObj);
        var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.DELETE_WORKDONE_MASTER_URL,
            data: dataObj
        };
        interceptorService.apiCall(config, function(response) {
            callback(response);
        });
    };

    service.updateWorkDoneMaster = function(data, callback) {
        console.log("adminAddTreatmentService.updateWorkDoneMaster()" + JSON.stringify(data));
        var dataObj = {};
        busyNotificationService.showBusyIndicator();
        dataObj["status"] = "";
        dataObj["message"] = "";
        dataObj["userName"] = null;
        dataObj["statusCode"] = "";
        dataObj["action"] = "updateWorkDoneMaster";
        dataObj["userCode"] = null;
        dataObj["userId"] = 0;
        dataObj["accessToken"] = null;
        dataObj["mobile"] = null;
        dataObj["email"] = null;
        dataObj["data"] = data;
        dataObj = interceptorService.encapsulateRequest(dataObj);
        console.log("final Request is " + dataObj);
        var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.UPDATE_WORKDONE_MASTER_URL,
            data: dataObj
        };
        //busyNotificationService.LOAD();
        interceptorService.apiCall(config, function(response) {
            //busyNotificationService.UNLOAD();
            callback(response);
            
        });
    };
		
  function initialize() {
    console.log("adminAddTreatmentService.initialize()");
	//busyNotificationService.showBusyIndicator();
    if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
      appEnvironment = localconfig;
    } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
      appEnvironment = serverconfig;
    }
  }

  initialize();

  return service;
}]);
