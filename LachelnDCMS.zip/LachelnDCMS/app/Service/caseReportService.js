myApp.factory('caseReportService', ['busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig', 'appConstants',
    function(busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, caseReportService) {

        var service = {};
        var appEnvironment = '';

        service.getReportService = function(data, callback) {
            console.log("caseReportService.getReportService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_CASE_REPORT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };

        service.downloadReportService = function(data, callback) {
            console.log("caseReportService.downloadReportService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.DOWNLOAD_REPORT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };
				
        function initialize() {
            console.log("caseReportService.initialize()");
            if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
                appEnvironment = localconfig;
            } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
                appEnvironment = serverconfig;
            }
        }

        initialize();

        return service;
    }
]);