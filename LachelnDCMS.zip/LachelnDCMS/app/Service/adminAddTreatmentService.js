myApp.factory('adminAddTreatmentService', [ 'busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig',  'appConstants',
function (busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, adminAddTreatmentService) {

  var service = {};
  var appEnvironment = '';

    service.saveTreatmentMaster = function(data, callback) {
        console.log("adminAddTreatmentService.saveTreatmentMaster()" + JSON.stringify(data));
        var dataObj = {};
        busyNotificationService.showBusyIndicator();
        dataObj["status"] = "";
        dataObj["message"] = "";
        dataObj["userName"] = null;
        dataObj["statusCode"] = "";
        dataObj["action"] = "saveTreatmentMaster";
        dataObj["userCode"] = null;
        dataObj["userId"] = 0;
        dataObj["accessToken"] = null;
        dataObj["mobile"] = null;
        dataObj["email"] = null;
        dataObj["data"] = data;
        dataObj = interceptorService.encapsulateRequest(dataObj);
        console.log("final Request is " + dataObj);
        var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.SAVE_TREATMENT_MASTER__URL,
            data: dataObj
        };
        //busyNotificationService.LOAD();
        interceptorService.apiCall(config, function(response) {
            //busyNotificationService.UNLOAD();
            callback(response);
            
        });
    };

    service.getTreatmentMasterService = function(callback) {
        console.log("adminAddTreatmentService.getTreatmentMasterService()");
        busyNotificationService.showBusyIndicator();
        var config = {
            method: appEnvironment.METHOD_GET,
            url: appEnvironment.GET_TREATMENT_MASTER_URL
        };
        //busyNotificationService.LOAD();
        interceptorService.apiCall(config, function(response) {
            //busyNotificationService.UNLOAD();
            callback(response);
            
        });
    };


    service.deleteTreatmentMasterService = function(data, callback) {
        console.log("adminAddTreatmentService.deleteTreatmentMasterService()" + JSON.stringify(data));
        var dataObj = {};
        busyNotificationService.showBusyIndicator();
        dataObj["status"] = "";
        dataObj["message"] = "";
        dataObj["userName"] = null;
        dataObj["statusCode"] = "";
        dataObj["action"] = "deleteTreatmentMaster";
        dataObj["userCode"] = null;
        dataObj["userId"] = 0;
        dataObj["accessToken"] = null;
        dataObj["mobile"] = null;
        dataObj["email"] = null;
        dataObj["data"] = data;
        dataObj = interceptorService.encapsulateRequest(dataObj);
        console.log("final Request is " + dataObj);
        var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.DELETE_TREATMENT_MASTER_URL,
            data: dataObj
        };
        interceptorService.apiCall(config, function(response) {
            callback(response);
        });
    };

    service.updateTreatmentMaster = function(data, callback) {
        console.log("adminAddTreatmentService.updateTreatmentMaster()" + JSON.stringify(data));
        var dataObj = {};
        busyNotificationService.showBusyIndicator();
        dataObj["status"] = "";
        dataObj["message"] = "";
        dataObj["userName"] = null;
        dataObj["statusCode"] = "";
        dataObj["action"] = "updateTreatmentMaster";
        dataObj["userCode"] = null;
        dataObj["userId"] = 0;
        dataObj["accessToken"] = null;
        dataObj["mobile"] = null;
        dataObj["email"] = null;
        dataObj["data"] = data;
        dataObj = interceptorService.encapsulateRequest(dataObj);
        console.log("final Request is " + dataObj);
        var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.UPDATE_TREATMENT_MASTER_URL,
            data: dataObj
        };
        //busyNotificationService.LOAD();
        interceptorService.apiCall(config, function(response) {
            //busyNotificationService.UNLOAD();
            callback(response);
            
        });
    };
		
  function initialize() {
    console.log("adminAddTreatmentService.initialize()");
	//busyNotificationService.showBusyIndicator();
    if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
      appEnvironment = localconfig;
    } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
      appEnvironment = serverconfig;
    }
  }

  initialize();

  return service;
}]);
