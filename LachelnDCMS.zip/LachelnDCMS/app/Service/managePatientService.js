myApp.factory('managePatientService', ['busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig', 'appConstants',
    function(busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, managePatientService) {

        var service = {};
        var appEnvironment = '';

        service.addPatientService = function(data, callback) {
            console.log("managePatientService.addPatientService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["userMobileNumber"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.ADD_PATIENT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };

        service.getAllPatientsService = function(callback) {
            console.log("managePatientService.getAllPatientsService()");
            //var dataObj = {};
            // busyNotificationService.showBusyIndicator();
            // dataObj["status"] = "";
            // dataObj["message"] = "";
            // dataObj["userName"] = null;
            // dataObj["statusCode"] = "";
            // dataObj["action"] = "getAllPatients";
            // dataObj["userCode"] = null;
            // dataObj["userId"] = 0;
            // dataObj["accessToken"] = null;
            // dataObj["userMobileNumber"] = null;
            // dataObj["email"] = null;
            // dataObj = interceptorService.encapsulateRequest(dataObj);
            // console.log("final Request is ", dataObj);
            var config = {
                method: appEnvironment.METHOD_GET,
                url: appEnvironment.GET_ALL_PATIENTS_URL
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };

        service.getTodaysWorkService = function(data, callback) {
            console.log("managePatientService.getTodaysWorkService()" + JSON.stringify(data));
            var dataObj = {};
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "getTodaysWork";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["userMobileNumber"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            busyNotificationService.showBusyIndicator();
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
			//busyNotificationService.LOAD();
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_TODAYS_WORK,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };


        service.fetchBillService = function(data, callback) {
            console.log("managePatientService.fetchBillService()" + JSON.stringify(data));
            var dataObj = {};
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "fetchBill";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["userMobileNumber"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            busyNotificationService.showBusyIndicator();
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
			//busyNotificationService.LOAD();
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.FETCH_BILL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
				//busyNotificationService.UNLOAD();
                callback(response);
            });
        };
		
		service.downloadPDFService = function(data, callback) {
            console.log("managePatientService.downloadPDFService()" + JSON.stringify(data));
            var dataObj = {};
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "generatePDF";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["userMobileNumber"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            busyNotificationService.showBusyIndicator();
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);

            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GENERATE_PDF,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };
		
		service.deletePatientService = function(data, callback) {
            console.log("managePatientService.deletePatientService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "deletePatient";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["userMobileNumber"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.DELETE_PATIENT,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };
		
		service.editPatientService = function(data, callback) {
            console.log("managePatientService.editPatientService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "update";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["userMobileNumber"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.UPDATE_PATIENT,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };




        function initialize() {
            console.log("managePatientService.initialize()");
            if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
                appEnvironment = localconfig;
            } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
                appEnvironment = serverconfig;
            }
        }

        initialize();

        return service;
    }
]);