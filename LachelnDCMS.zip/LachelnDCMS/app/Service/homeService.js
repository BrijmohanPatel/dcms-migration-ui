myApp.factory('homeService', [ 'busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig',  'appConstants',
function (busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, homeService) {

  var service = {};
  var appEnvironment = '';

  service.getDoctorMasterService = function(data, callback) {
            console.log("homeService.getDoctorMasterService()" + JSON.stringify(data));
            var dataObj = {};
			busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "getDoctorMaster";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_DOCTOR_MASTER,
                data: dataObj
            };
			//busyNotificationService.LOAD();
            interceptorService.apiCall(config, function(response) {
				//busyNotificationService.UNLOAD();
                callback(response);
				
            });
        };
		
		
		
		
		
		service.getWorkMasterService = function(data, callback) {
            console.log("homeService.getWorkMasterService()" + JSON.stringify(data));
            var dataObj = {};
			busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "getworkMaster";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_WORK_MASTER,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };
		
  function initialize() {
    console.log("homeService.initialize()");
	busyNotificationService.showBusyIndicator();
    if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
      appEnvironment = localconfig;
    } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
      appEnvironment = serverconfig;
    }
  }

  initialize();

  return service;
}]);
