myApp.factory('AuthenticationService', ['busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig', 'appConstants',
    function (busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants) {

        var service = {};
        var appEnvironment = '';

	service.login = function (data, callback) {
		console.log("AuthenticationService.login()" + JSON.stringify(data));
		data["password"] = md5(data["password"]);
		var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = data["userName"];
            dataObj["statusCode"] = "";
            dataObj["action"] = "login";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);

		var config = {
			method: appEnvironment.METHOD_POST,
			url: appEnvironment.LOGIN_URL,
			data: dataObj,
		};

		interceptorService.apiCall(config, function (response) {callback(response);});
	};

    service.signout = function (data, callback) {
      console.log("AuthenticationService.signout()");
      var dataObj={};
      busyNotificationService.showBusyIndicator();
      dataObj= {"data":data};
      dataObj["action"] = "signout";
      dataObj["loginId"] = $rootScope.globals.loginId;
      dataObj["accessToken"] = $rootScope.globals.accessToken;
      dataObj = interceptorService.encapsulateRequest(dataObj);

      var config = {
        method: appEnvironment.METHOD_POST,
        url: appEnvironment.LOGIN_URL,
        data: dataObj,
      };

      interceptorService.apiCall(config, function (response) {callback(response);});
    };

		service.fetchNotificationCount = function(data, callback){
			console.log("notificationService.fetchNotificationCount()");
			var dataObj={};
			busyNotificationService.showBusyIndicator();
			dataObj= {"data":data};
			dataObj["action"] = "getNotification";
			dataObj["loginId"] = $rootScope.globals.loginId;
			dataObj["accessToken"] = $rootScope.globals.accessToken;
			dataObj = interceptorService.encapsulateRequest(dataObj);
			var config = {
				method: appEnvironment.METHOD_POST,
				url: appEnvironment.NOTIFICATION_URL,
				data: dataObj
			};
			interceptorService.apiCall(config, function (response) {callback(response);});

		};

  service.checkEmailSendOTPService = function (data, callback) {
    console.log("AuthenticationService.checkEmailSendOTPService()");
    var dataObj={};
    busyNotificationService.showBusyIndicator();
    dataObj= {"data":data};
    dataObj = interceptorService.encapsulateRequest(dataObj);
    var config = {
      method: appEnvironment.METHOD_POST,
      url: appEnvironment.LOGIN_URL,
      data: dataObj,
    };

    interceptorService.apiCall(config, function (response) {callback(response);});
      };

    service.forgotPasswordService = function(data, callback){
     console.log("homeService.forgotPasswordService()"+JSON.stringify(data));
     var dataObj={};
     busyNotificationService.showBusyIndicator();
     dataObj= {"data":data};
     dataObj["action"] = data["action"];
     dataObj["loginId"] = data["loginId"];
     dataObj = interceptorService.encapsulateRequest(dataObj);
     var config = {
       method: appEnvironment.METHOD_POST,
       url: appEnvironment.BP_REGISTRATION_URL,
       data: dataObj
     };
     interceptorService.apiCall(config, function (response) {callback(response);});
   };



        service.registerUserService = function (data, callback) {
          console.log("Registration called");
          console.log("AuthenticationService.registerUserService() >>"+JSON.stringify(data));
          var dataObj={};
		  var pwd = md5(data["pwd"]);
          dataObj["data"] = data;
		  dataObj["data"]["password"] = pwd;
          dataObj["action"]= "login";
          dataObj = interceptorService.encapsulateRequest(dataObj);
          busyNotificationService.showBusyIndicator();
          var config = {
            method: appEnvironment.METHOD_POST,
            url: appEnvironment.LOGIN_URL,
            data: dataObj,
          };

          interceptorService.apiCall(config, function (response) {callback(response);});
        };

        service.otp = function (data, callback) {
			console.log("AuthenticationService.otp()");
			var dataObj={};
			busyNotificationService.showBusyIndicator();

			dataObj= {"data":data};
			dataObj["loginId"]= $rootScope.globals.loginId;
			dataObj["action"]= "validateOTP";
			dataObj["accessToken"]= $rootScope.globals.accessToken;
			dataObj = interceptorService.encapsulateRequest(dataObj);

			var config = {
				method: appEnvironment.METHOD_POST,
				url: appEnvironment.OTP_URL,
				data: dataObj
			};

			interceptorService.apiCall(config, function (response) {callback(response);
			});
        };

		service.resetSession = function (data, callback) {
			console.log("AuthenticationService.resetSession()");
			var dataObj={};
			busyNotificationService.showBusyIndicator();

			dataObj= {"data":data};
			dataObj["loginId"]= $rootScope.globals.loginId;
			dataObj["accessToken"]= $rootScope.globals.accessToken;
			dataObj = interceptorService.encapsulateRequest(dataObj);

			var config = {
				method: appEnvironment.METHOD_POST,
				url: appEnvironment.SESSION_URL,
				data: dataObj
			};

			interceptorService.apiCall(config, function (response) {callback(response);
			});
        };

		function initialize() {
            console.log("AuthenticationService.initialize()");
            if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
                appEnvironment = localconfig;
            } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
                appEnvironment = serverconfig;
            }
        }

		initialize();

    return service;
}]);
