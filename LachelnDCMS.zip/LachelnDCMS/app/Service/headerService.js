myApp.factory('headerService', ['busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig', 'appConstants',
    function(busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, headerService) {

        var service = {};
        var appEnvironment = '';

        service.searchPatientService = function(data, callback) {
            console.log("headerService.searchPatientService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.SEARCH_PATIENT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };
		
		service.selectPatient = function(data, callback) {
            console.log("headerService.selectPatientService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_PLAN_AND_TREATMENT_DATA,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };
		
		
        function initialize() {
            console.log("headerService.initialize()");
            if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
                appEnvironment = localconfig;
            } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
                appEnvironment = serverconfig;
            }
        }

        initialize();

        return service;
    }
]);