myApp.factory('manageTreatmentService', ['busyNotificationService', 'modalService', '$http', '$cookieStore', '$rootScope', '$timeout', 'config', 'cryptoService', 'interceptorService', 'localconfig', 'serverconfig', 'appConstants',
    function(busyNotificationService, modalService, $http, $cookieStore, $rootScope, $timeout, config, cryptoService, interceptorService, localconfig, serverconfig, appConstants, manageTreatmentService) {

        var service = {};
        var appEnvironment = '';

		service.addTreatmentService = function(data, callback) {
          console.log("manageTreatmentService.addTreatmentService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "addTreatment";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.ADD_TREATMENT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };
		
		service.getTreatmentService = function(data, callback) {
          console.log("manageTreatmentService.addTreatmentService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "getTreatments";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.GET_TREATMENTS_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
				//busyNotificationService.UNLOAD();
            });
        };

        service.deleteTreatmentService = function(data, callback) {
            console.log("manageTreatmentService.deleteTreatmentService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "deleteTreatment";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.DELETE_TREATMENT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };

        service.updateTreatmentService = function(data, callback) {
            console.log("manageTreatmentService.updateTreatmentService()" + JSON.stringify(data));
            var dataObj = {};
            busyNotificationService.showBusyIndicator();
            dataObj["status"] = "";
            dataObj["message"] = "";
            dataObj["userName"] = null;
            dataObj["statusCode"] = "";
            dataObj["action"] = "updateTreatment";
            dataObj["userCode"] = null;
            dataObj["userId"] = 0;
            dataObj["accessToken"] = null;
            dataObj["mobile"] = null;
            dataObj["email"] = null;
            dataObj["data"] = data;
            dataObj = interceptorService.encapsulateRequest(dataObj);
            console.log("final Request is " + dataObj);
            var config = {
                method: appEnvironment.METHOD_POST,
                url: appEnvironment.UPDATE_TREATMENT_URL,
                data: dataObj
            };
            interceptorService.apiCall(config, function(response) {
                callback(response);
            });
        };

        service.fetchworkDoneMasterService = function(callback) {
            console.log("manageTreatmentService.fetchworkDoneMasterService()");
            busyNotificationService.showBusyIndicator();
            var config = {
                method: appEnvironment.METHOD_GET,
                url: appEnvironment.GET_WORKDONE_MASTER_URL
            };
            //busyNotificationService.LOAD();
            interceptorService.apiCall(config, function(response) {
                //busyNotificationService.UNLOAD();
                callback(response);
                
            });
        };

        function initialize() {
            console.log("manageTreatmentService.initialize()");
            if (APP_ENVIRONMENT === config.ENVIRONMENT_LOCAL) {
                appEnvironment = localconfig;
            } else if (APP_ENVIRONMENT === config.ENVIRONMENT_SERVER) {
                appEnvironment = serverconfig;
            }
        }

        initialize();

        return service;
    }
]);