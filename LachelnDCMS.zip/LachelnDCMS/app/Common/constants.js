(function () {

    'use strict';

    /**
     * Defines application-wide key value pairs
     **/

    myApp.constant('config', {
        ENVIRONMENT_LOCAL: "local",
        ENVIRONMENT_SERVER: "server"
    });
    myApp.constant('responseStatus', {
        STATUS_FAILED: "failed",
        STATUS_SUCCESS: "success"
    });
    myApp.constant('localconfig', {
        LOGIN_URL: 'app/Data/login.json',
    		LOGOUT_URL: 'app/Data/home.json',
    		METHOD_POST: 'POST'
    });

    myApp.constant('serverconfig', {
      LOGIN_URL: APP_API_URL + 'login',
	  
      SEARCH_PATIENT_URL: APP_API_URL + 'patients/searchPatient',
      ADD_PATIENT_URL: APP_API_URL + 'patients/addPatient',
      GET_ALL_PATIENTS_URL: APP_API_URL + 'patients/getAllPatients',
      DELETE_PATIENT: APP_API_URL + 'patients/deletePatient',
      UPDATE_PATIENT: APP_API_URL + 'patients/updatePatient',

	  ADD_TREATMENT_PLAN_URL: APP_API_URL + 'addTreatmentPlan',
      DELETE_TREATMENT_PLAN_URL: APP_API_URL + 'deleteTreatmentPlan',
      GET_PLAN_AND_TREATMENT_DATA: APP_API_URL + 'selectPatient',
      UPDATE_TREATMENT_DATA_URL: APP_API_URL + 'updateTreatmentPlan',
      
      ADD_TREATMENT_URL: APP_API_URL + 'addTreatment',
	  GET_TREATMENTS_URL: APP_API_URL + 'getTreatments',
      DELETE_TREATMENT_URL: APP_API_URL + 'deleteTreatment',
      UPDATE_TREATMENT_URL: APP_API_URL + 'updateTreatment',
    
      SAVE_TREATMENT_MASTER__URL: APP_API_URL + 'saveTreatmentMaster',
      GET_TREATMENT_MASTER_URL: APP_API_URL + 'getTreatmentMaster',
      DELETE_TREATMENT_MASTER_URL: APP_API_URL + 'deleteTreatmentMaster',
      UPDATE_TREATMENT_MASTER_URL: APP_API_URL + 'updateTreatmentMaster',

      SAVE_WORKDONE_MASTER__URL: APP_API_URL + 'saveWorkdoneMaster',
      GET_WORKDONE_MASTER_URL: APP_API_URL + 'getWorkdoneMaster',
      DELETE_WORKDONE_MASTER_URL: APP_API_URL + 'deleteWorkdoneMaster',
      UPDATE_WORKDONE_MASTER_URL: APP_API_URL + 'updateWorkdoneMaster',

      GET_CASE_REPORT_URL: APP_API_URL + 'getCaseReport',
      DOWNLOAD_REPORT_URL: APP_API_URL + 'downloadReport',

      METHOD_POST: 'POST',
      METHOD_GET: 'GET'
    });
	
    myApp.constant('appConstants', {
        SUCCESS: "success",
        ERROR: "error",
        EVENTS: {
            OPEN_MODAL: "OPEN_MODAL",
            CLOSE_MODAL: "CLOSE_MODAL"
        },
		CUST_PRIORITY: [],
        PRIORITY: [],
        AUTO_FLOW: [],
        FIELDS: [],
        NAV_BAR_CONFIG: {},
        ROLES: {},
        ACTIONS: [],
        REQUEST_SUBMITTED_TEXT: "Request submitted successfully!",
        UPPER_CASE_CHARS: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
        LOWER_CASE_CHARS: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
        ADMIN_PROCESS_DESCIPTION_CHARS: [' ', ',', '.', '-'],
        ADMIN_DOCUMENT_TYPE_MASTER_CHARS: [' ', '-', '.'],
        NUMBERS: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
        SPECIAL_CHARACTERS: ['-'],
        COMMENT_SPECIAL_CHARACTERS: ['-', '.', '@', '$', '%', '/', '&', '*', '+', '='],
    		ENCRY_CODE: "Mitron!2#",
    		SESSION_TIMEOUT_POPUP : 120000,
    });

    myApp.constant('appRegEx', {
        // USER_NAME_REGEX:/^[^A-Z0-9]$/
    });
})();
