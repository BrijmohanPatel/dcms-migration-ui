'use strict';

/**
 * Defines application-wide key value pairs
 **/

Application.Constants.constants('configurations', {
    BASE_CONTEXT: '',
    STATIC_CONTENT_CONTEXT: ''
});

Application.Constants.constants('validationRegEx', {
    LOGIN_ID: '',
    STATIC_CONTENT_CONTEXT: ''
});

Application.Constants.constants('userEntitlementKeys', {
    ADMIN: '',
    BRANCH: '',
    WCS: '',
	COMPLIANCE: '',
	SCRUTINIZER_1: '',
	SCRUTINIZER_2: '',
	FINACLE_MAKER: '',
	FINACLE_CHECKER: '',
	SWIFT_MAKER: '',
	SWIFT_CHECKER: '',
	SFMS_MAKER: '',
	SFMS_CHECKER: '',
	SFMS_AUTHORIZER: '',
	MANAGEMENT: ''
});